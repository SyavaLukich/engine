/*
 * OpenGL 2.0 / extension stress test for OSMesa.
 *
 * Tests the extensions listed in the problem statement that OSMesa
 * claims to support, exercising them as they are intended to be used.
 *
 * Extensions tested:
 *   GL_EXT_polygon_offset
 *   GL_EXT_texture_object
 *   GL_EXT_subtexture
 *   GL_EXT_texture3D
 *   GL_ARB_multitexture
 *   GL_ARB_texture_compression
 *   GL_EXT_paletted_texture
 *   GL_ARB_imaging  (includes GL_EXT_blend_minmax, GL_SGI_color_matrix,
 *                    GL_SGI_color_table, GL_SGI_texture_color_table)
 *   GL_EXT_blend_minmax
 *   GL_SGI_color_table
 *   GL_SGI_texture_color_table
 *   GL_ARB_vertex_buffer_object
 *   GL_EXT_multi_draw_arrays
 *   GL_ARB_depth_texture
 *   GL_ARB_shadow
 *   GL_EXT_texture_rectangle
 *   GL_EXT_framebuffer_object
 *   GL_ARB_framebuffer_object
 *   GL_ARB_fragment_program
 *   GL_ARB_vertex_program
 *   GL_ARB_shader_objects
 *   GL_ARB_vertex_shader
 *   GL_ARB_occlusion_query
 *
 * This program is in the public domain.
 */

#define _USE_MATH_DEFINES
#define GL_GLEXT_PROTOTYPES
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "OSMesa/gl.h"
#include "OSMesa/glext.h"
#include "OSMesa/osmesa.h"

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

static int g_failed = 0;

static int
check_ext(const char *name)
{
    const char *exts = (const char *)glGetString(GL_EXTENSIONS);
    if (!exts || !strstr(exts, name)) {
	fprintf(stderr, "  SKIP: %s not advertised\n", name);
	return 0;
    }
    return 1;
}

static int
check_gl_error(const char *where)
{
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
	fprintf(stderr, "  GL error 0x%x at %s\n", (unsigned)err, where);
	return 1;
    }
    return 0;
}

static void
clear_errors(void)
{
    while (glGetError() != GL_NO_ERROR)
	;
}

/* Draw a full-screen quad */
static void
draw_quad(void)
{
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f(1.0f, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f(1.0f, 1.0f); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f, 1.0f); glVertex2f(-1.0f,  1.0f);
    glEnd();
}

/* Compile+link a simple GLSL program */
static GLuint
make_program(const char *vert_src, const char *frag_src)
{
    GLuint vert = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vert, 1, &vert_src, NULL);
    glCompileShader(vert);
    GLint ok = 0;
    glGetShaderiv(vert, GL_COMPILE_STATUS, &ok);
    if (!ok) {
	char log[512];
	glGetShaderInfoLog(vert, sizeof(log), NULL, log);
	fprintf(stderr, "  Vert shader error: %s\n", log);
	glDeleteShader(vert);
	return 0;
    }

    GLuint frag = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(frag, 1, &frag_src, NULL);
    glCompileShader(frag);
    glGetShaderiv(frag, GL_COMPILE_STATUS, &ok);
    if (!ok) {
	char log[512];
	glGetShaderInfoLog(frag, sizeof(log), NULL, log);
	fprintf(stderr, "  Frag shader error: %s\n", log);
	glDeleteShader(vert);
	glDeleteShader(frag);
	return 0;
    }

    GLuint prog = glCreateProgram();
    glAttachShader(prog, vert);
    glAttachShader(prog, frag);
    glLinkProgram(prog);
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    glDeleteShader(vert);
    glDeleteShader(frag);
    if (!ok) {
	char log[512];
	glGetProgramInfoLog(prog, sizeof(log), NULL, log);
	fprintf(stderr, "  Program link error: %s\n", log);
	glDeleteProgram(prog);
	return 0;
    }
    return prog;
}

/* ------------------------------------------------------------------ */
/* Test 1: Extension advertisement                                     */
/* ------------------------------------------------------------------ */
static void
test_extension_strings(void)
{
    printf("Test 1: Extension advertisement\n");

    /* Extensions from the problem statement that OSMesa claims to support */
    static const char * const supported[] = {
	"GL_EXT_polygon_offset",
	"GL_EXT_texture_object",
	"GL_EXT_subtexture",
	"GL_EXT_texture3D",
	"GL_ARB_multitexture",
	"GL_ARB_texture_compression",
	"GL_EXT_paletted_texture",
	"GL_ARB_imaging",
	"GL_EXT_blend_minmax",
	"GL_SGI_color_table",
	"GL_SGI_texture_color_table",
	"GL_ARB_vertex_buffer_object",
	"GL_EXT_multi_draw_arrays",
	"GL_ARB_depth_texture",
	"GL_EXT_framebuffer_object",
	"GL_ARB_framebuffer_object",
	"GL_ARB_shadow",
	"GL_EXT_texture_rectangle",
	"GL_ARB_fragment_program",
	"GL_ARB_vertex_program",
	"GL_ARB_shader_objects",
	"GL_ARB_vertex_shader",
	"GL_ARB_occlusion_query",
	"GL_ARB_framebuffer_sRGB",
	"GL_EXT_framebuffer_sRGB",
	"GL_EXT_texture_integer",
	NULL
    };

    const char *exts = (const char *)glGetString(GL_EXTENSIONS);
    if (!exts) {
	fprintf(stderr, "  FAIL: glGetString(GL_EXTENSIONS) returned NULL\n");
	g_failed++;
	return;
    }

    int all_ok = 1;
    for (int i = 0; supported[i]; i++) {
	if (!strstr(exts, supported[i])) {
	    fprintf(stderr, "  FAIL: %s not advertised\n", supported[i]);
	    all_ok = 0;
	    g_failed++;
	}
    }
    if (all_ok)
	printf("  PASS: all expected extensions advertised\n");
}

/* ------------------------------------------------------------------ */
/* Test 2: GL_EXT_polygon_offset                                       */
/* ------------------------------------------------------------------ */
static void
test_polygon_offset(int W, int H)
{
    printf("Test 2: GL_EXT_polygon_offset\n");

    if (!check_ext("GL_EXT_polygon_offset"))
	return;

    clear_errors();

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1, 1, -1, 1, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDepthRange(0.0, 1.0);

    /* Draw a base polygon and read its depth */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-0.5f, -0.5f, 0.0f);
    glVertex3f( 0.5f, -0.5f, 0.0f);
    glVertex3f( 0.5f,  0.5f, 0.0f);
    glVertex3f(-0.5f,  0.5f, 0.0f);
    glEnd();
    glFinish();

    GLfloat depth_base = 0.0f;
    glReadPixels(W/2, H/2, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &depth_base);

    /* Draw the same polygon with a positive offset */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-0.5f, -0.5f, 0.0f);
    glVertex3f( 0.5f, -0.5f, 0.0f);
    glVertex3f( 0.5f,  0.5f, 0.0f);
    glVertex3f(-0.5f,  0.5f, 0.0f);
    glEnd();
    glFinish();

    GLfloat depth_offset = 0.0f;
    glReadPixels(W/2, H/2, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &depth_offset);

    glDisable(GL_POLYGON_OFFSET_FILL);
    glDisable(GL_DEPTH_TEST);

    if (check_gl_error("polygon_offset")) {
	fprintf(stderr, "  FAIL: GL error during polygon offset test\n");
	g_failed++;
	return;
    }

    /* With positive offset, depth should be pushed farther (larger value) */
    if (depth_offset > depth_base) {
	printf("  PASS: polygon offset increases depth (%.4f -> %.4f)\n",
	       depth_base, depth_offset);
    } else {
	fprintf(stderr,
		"  FAIL: polygon offset did not increase depth "
		"(base=%.4f, offset=%.4f)\n",
		depth_base, depth_offset);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 3: GL_EXT_texture_object                                       */
/* ------------------------------------------------------------------ */
static void
test_texture_object(int W, int H)
{
    printf("Test 3: GL_EXT_texture_object\n");

    if (!check_ext("GL_EXT_texture_object"))
	return;

    clear_errors();

    /* Create two textures - one red, one green */
    GLuint textures[2];
    glGenTextures(2, textures);

    GLubyte red[4]   = { 255, 0, 0, 255 };
    GLubyte green[4] = { 0, 255, 0, 255 };

    glBindTexture(GL_TEXTURE_2D, textures[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, red);

    glBindTexture(GL_TEXTURE_2D, textures[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, green);

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    /* Render with the red texture */
    glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, textures[0]);
    draw_quad();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    int red_ok = (px[0] > 200 && px[1] < 50 && px[2] < 50);

    /* Render with the green texture */
    glClear(GL_COLOR_BUFFER_BIT);
    glBindTexture(GL_TEXTURE_2D, textures[1]);
    draw_quad();
    glFinish();

    GLubyte px2[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px2);

    int green_ok = (px2[0] < 50 && px2[1] > 200 && px2[2] < 50);

    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(2, textures);

    if (check_gl_error("texture_object")) {
	fprintf(stderr, "  FAIL: GL error during texture object test\n");
	g_failed++;
	return;
    }

    if (red_ok && green_ok) {
	printf("  PASS: texture objects work (red=%d,%d,%d  green=%d,%d,%d)\n",
	       px[0], px[1], px[2], px2[0], px2[1], px2[2]);
    } else {
	fprintf(stderr,
		"  FAIL: texture object switching failed "
		"(red=%d,%d,%d  green=%d,%d,%d)\n",
		px[0], px[1], px[2], px2[0], px2[1], px2[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 4: GL_EXT_subtexture  (glTexSubImage2D)                        */
/* ------------------------------------------------------------------ */
static void
test_subtexture(int W, int H)
{
    printf("Test 4: GL_EXT_subtexture\n");

    if (!check_ext("GL_EXT_subtexture"))
	return;

    clear_errors();

    /* Create a 2x2 all-blue texture, then replace the bottom-left with red */
    GLubyte blue[4*4];
    for (int i = 0; i < 4; i++) {
	blue[i*4+0] = 0;
	blue[i*4+1] = 0;
	blue[i*4+2] = 255;
	blue[i*4+3] = 255;
    }
    GLubyte red_patch[4] = { 255, 0, 0, 255 };

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 2, 2, 0, GL_RGBA, GL_UNSIGNED_BYTE, blue);
    /* Replace bottom-left 1x1 texel with red */
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, red_patch);

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    /* Sample the red texel (bottom-left = texcoord 0,0) */
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f(0.5f, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f(0.5f, 0.5f); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f, 0.5f); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(1, &tex);

    if (check_gl_error("subtexture")) {
	fprintf(stderr, "  FAIL: GL error during subtexture test\n");
	g_failed++;
	return;
    }

    if (px[0] > 200 && px[1] < 50 && px[2] < 50) {
	printf("  PASS: glTexSubImage2D updated texel correctly (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: glTexSubImage2D did not update texel correctly "
		"(expected ~255,0,0 got %d,%d,%d)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 5: GL_EXT_texture3D                                            */
/* ------------------------------------------------------------------ */
static void
test_texture3d(int W, int H)
{
    printf("Test 5: GL_EXT_texture3D\n");

    if (!check_ext("GL_EXT_texture3D"))
	return;

    clear_errors();

    /* Create a 2x2x2 3D texture, first slice red, second slice blue */
    GLubyte data[2*2*2*4];
    for (int z = 0; z < 2; z++) {
	for (int i = 0; i < 4; i++) {
	    int idx = (z*4 + i)*4;
	    data[idx+0] = (z == 0) ? 255 : 0;
	    data[idx+1] = 0;
	    data[idx+2] = (z == 0) ? 0 : 255;
	    data[idx+3] = 255;
	}
    }

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_3D, tex);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexImage3D(GL_TEXTURE_3D, 0, GL_RGBA, 2, 2, 2, 0,
		 GL_RGBA, GL_UNSIGNED_BYTE, data);

    int created_ok = !check_gl_error("glTexImage3D");

    /* Also test glTexSubImage3D - replace second slice with green */
    if (created_ok) {
	GLubyte green_slice[2*2*4];
	for (int i = 0; i < 4; i++) {
	    green_slice[i*4+0] = 0;
	    green_slice[i*4+1] = 255;
	    green_slice[i*4+2] = 0;
	    green_slice[i*4+3] = 255;
	}
	glTexSubImage3D(GL_TEXTURE_3D, 0, 0, 0, 1, 2, 2, 1,
			GL_RGBA, GL_UNSIGNED_BYTE, green_slice);
    }

    /* Render using 3D texture - sample at r=0.25 (first slice, red) */
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_3D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glTexCoord3f(0.0f, 0.0f, 0.25f); glVertex2f(-1.0f, -1.0f);
    glTexCoord3f(1.0f, 0.0f, 0.25f); glVertex2f( 1.0f, -1.0f);
    glTexCoord3f(1.0f, 1.0f, 0.25f); glVertex2f( 1.0f,  1.0f);
    glTexCoord3f(0.0f, 1.0f, 0.25f); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glDisable(GL_TEXTURE_3D);
    glDeleteTextures(1, &tex);

    if (check_gl_error("texture3d")) {
	fprintf(stderr, "  FAIL: GL error during texture3D test\n");
	g_failed++;
	return;
    }

    /* First slice should be red */
    if (px[0] > 200 && px[1] < 50 && px[2] < 50) {
	printf("  PASS: 3D texture first slice sampled red (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: 3D texture did not return red for first slice "
		"(got %d,%d,%d)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 6: GL_ARB_multitexture                                         */
/* ------------------------------------------------------------------ */
static void
test_multitexture(int W, int H)
{
    printf("Test 6: GL_ARB_multitexture\n");

    if (!check_ext("GL_ARB_multitexture"))
	return;

    clear_errors();

    /* Create two textures: one red, one that contributes green */
    GLuint tex[2];
    glGenTextures(2, tex);

    GLubyte red[4]    = { 255,   0,   0, 255 };
    GLubyte green[4]  = {   0, 255,   0, 255 };

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, red);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, tex[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, green);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_ADD);

    glEnable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
    glEnable(GL_TEXTURE_2D);

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClientActiveTexture(GL_TEXTURE0);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glMultiTexCoord2f(GL_TEXTURE0, 0.5f, 0.5f);
    glMultiTexCoord2f(GL_TEXTURE1, 0.5f, 0.5f);
    glVertex2f(-1.0f, -1.0f);
    glMultiTexCoord2f(GL_TEXTURE0, 0.5f, 0.5f);
    glMultiTexCoord2f(GL_TEXTURE1, 0.5f, 0.5f);
    glVertex2f( 1.0f, -1.0f);
    glMultiTexCoord2f(GL_TEXTURE0, 0.5f, 0.5f);
    glMultiTexCoord2f(GL_TEXTURE1, 0.5f, 0.5f);
    glVertex2f( 1.0f,  1.0f);
    glMultiTexCoord2f(GL_TEXTURE0, 0.5f, 0.5f);
    glMultiTexCoord2f(GL_TEXTURE1, 0.5f, 0.5f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    /* Disable and clean up */
    glActiveTexture(GL_TEXTURE1);
    glDisable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(2, tex);

    if (check_gl_error("multitexture")) {
	fprintf(stderr, "  FAIL: GL error during multitexture test\n");
	g_failed++;
	return;
    }

    /* With GL_REPLACE on unit 0 (red) and GL_ADD on unit 1 (green),
     * result should have R>0 and G>0 */
    if (px[0] > 100 && px[1] > 100) {
	printf("  PASS: multitexture combine result (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: multitexture combine gave unexpected result (%d,%d,%d)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 7: GL_ARB_texture_compression                                  */
/* ------------------------------------------------------------------ */
static void
test_texture_compression(void)
{
    printf("Test 7: GL_ARB_texture_compression\n");

    if (!check_ext("GL_ARB_texture_compression"))
	return;

    clear_errors();

    /* Query compressed formats */
    GLint num_formats = 0;
    glGetIntegerv(GL_NUM_COMPRESSED_TEXTURE_FORMATS_ARB, &num_formats);

    if (check_gl_error("GL_NUM_COMPRESSED_TEXTURE_FORMATS_ARB")) {
	fprintf(stderr, "  FAIL: error querying compressed texture formats\n");
	g_failed++;
	return;
    }

    printf("  INFO: %d compressed formats available\n", num_formats);

    /* Test uploading a compressed texture with known data (DXT/S3TC or
     * any supported format).  We first create an uncompressed texture and
     * verify glGetTexLevelParameteriv returns an internal format that is
     * accepted without error; this confirms the path is usable. */
    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    /* Use GL_COMPRESSED_RGBA_ARB as a hint - Mesa will choose the format */
    GLubyte data[4*4*4];
    for (int i = 0; i < 16; i++) {
	data[i*4+0] = 100;
	data[i*4+1] = 150;
	data[i*4+2] = 200;
	data[i*4+3] = 255;
    }
    glTexImage2D(GL_TEXTURE_2D, 0, GL_COMPRESSED_RGBA_ARB, 4, 4, 0,
		 GL_RGBA, GL_UNSIGNED_BYTE, data);

    if (check_gl_error("glTexImage2D GL_COMPRESSED_RGBA_ARB")) {
	fprintf(stderr, "  FAIL: compressed texture creation failed\n");
	glDeleteTextures(1, &tex);
	g_failed++;
	return;
    }

    GLint compressed = GL_FALSE;
    glGetTexLevelParameteriv(GL_TEXTURE_2D, 0,
			     GL_TEXTURE_COMPRESSED_ARB, &compressed);
    check_gl_error("GL_TEXTURE_COMPRESSED_ARB query");

    glDeleteTextures(1, &tex);

    printf("  PASS: GL_ARB_texture_compression texture created "
	   "(compressed=%s)\n", compressed ? "yes" : "no");
}

/* ------------------------------------------------------------------ */
/* Test 8: GL_EXT_paletted_texture                                     */
/* ------------------------------------------------------------------ */
static void
test_paletted_texture(int W, int H)
{
    printf("Test 8: GL_EXT_paletted_texture\n");

    if (!check_ext("GL_EXT_paletted_texture"))
	return;

    clear_errors();

    /*
     * Build a 2x2 paletted (COLOR_INDEX8) texture.
     * Palette entry 0 = red, entry 1 = blue.
     * Texels: [0, 1, 1, 0] → top-left and bottom-right are red.
     */
    GLubyte palette[2*4] = {
	255,   0,   0, 255,   /* index 0 = red  */
	  0,   0, 255, 255,   /* index 1 = blue */
    };
    GLubyte indices[2*2] = { 0, 1, 1, 0 };

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    /* Install the palette */
    glColorTableEXT(GL_TEXTURE_2D, GL_RGBA, 2, GL_RGBA, GL_UNSIGNED_BYTE, palette);

    if (check_gl_error("glColorTableEXT")) {
	fprintf(stderr, "  FAIL: glColorTableEXT returned error\n");
	glDeleteTextures(1, &tex);
	g_failed++;
	return;
    }

    /* Upload indexed image */
    glTexImage2D(GL_TEXTURE_2D, 0, GL_COLOR_INDEX8_EXT, 2, 2, 0,
		 GL_COLOR_INDEX, GL_UNSIGNED_BYTE, indices);

    if (check_gl_error("glTexImage2D COLOR_INDEX8_EXT")) {
	fprintf(stderr, "  FAIL: paletted texture upload failed\n");
	glDeleteTextures(1, &tex);
	g_failed++;
	return;
    }

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    /* Sample index-0 texel (bottom-left), should be red */
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f(0.5f, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f(0.5f, 0.5f); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f, 0.5f); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(1, &tex);

    if (check_gl_error("paletted_texture render")) {
	fprintf(stderr, "  FAIL: GL error rendering paletted texture\n");
	g_failed++;
	return;
    }

    if (px[0] > 200 && px[1] < 50 && px[2] < 50) {
	printf("  PASS: paletted texture palette index 0 = red (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: paletted texture palette lookup wrong "
		"(expected ~255,0,0 got %d,%d,%d)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 9: GL_EXT_blend_minmax  (and GL_ARB_imaging blend modes)       */
/* ------------------------------------------------------------------ */
static void
test_blend_minmax(int W, int H)
{
    printf("Test 9: GL_EXT_blend_minmax\n");

    if (!check_ext("GL_EXT_blend_minmax"))
	return;

    clear_errors();

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);

    /* Clear to a medium gray (128,128,128) */
    glClearColor(128.0f/255.0f, 128.0f/255.0f, 128.0f/255.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    /* Enable blending with GL_MIN: result should be min of src and dst */
    glEnable(GL_BLEND);
    glBlendEquation(GL_MIN);

    /* Draw a brighter quad (200,200,200) */
    glColor4ub(200, 200, 200, 255);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px_min[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_min);

    /* GL_MIN: result = min(200,128) = 128 (the background stays) */

    /* Now test GL_MAX */
    glClear(GL_COLOR_BUFFER_BIT);
    glBlendEquation(GL_MAX);

    /* Draw a dimmer quad (64,64,64) */
    glColor4ub(64, 64, 64, 255);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px_max[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_max);

    /* GL_MAX: result = max(64,128) = 128 (the background wins) */

    glDisable(GL_BLEND);
    glBlendEquation(GL_FUNC_ADD);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

    if (check_gl_error("blend_minmax")) {
	fprintf(stderr, "  FAIL: GL error during blend minmax test\n");
	g_failed++;
	return;
    }

    /* GL_MIN test: drawing 200 over 128 background → should stay ~128 */
    int min_ok = (px_min[0] < 150);
    /* GL_MAX test: drawing 64 over 128 background → should stay ~128 */
    int max_ok = (px_max[0] > 100);

    if (min_ok && max_ok) {
	printf("  PASS: GL_MIN=%d (expected ~128), GL_MAX=%d (expected ~128)\n",
	       px_min[0], px_max[0]);
    } else {
	fprintf(stderr,
		"  FAIL: blend minmax: GL_MIN got %d (expected ~128), "
		"GL_MAX got %d (expected ~128)\n",
		px_min[0], px_max[0]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 10: GL_SGI_color_table                                         */
/* ------------------------------------------------------------------ */
static void
test_sgi_color_table(int W, int H)
{
    printf("Test 10: GL_SGI_color_table\n");

    if (!check_ext("GL_SGI_color_table"))
	return;

    clear_errors();

    /*
     * The GL_SGI_color_table extension provides color table lookup in
     * the PIXEL TRANSFER pipeline (glReadPixels, glDrawPixels, etc.)
     * and also via GL_SGI_texture_color_table for texture fetches.
     *
     * Part A: test GL_COLOR_TABLE applied during glReadPixels.
     *   - Render a bright-red quad (200, 0, 0, 255).
     *   - Install a GL_COLOR_TABLE that maps all R values to exactly 50
     *     and all G/B values to their input (identity for G and B).
     *   - Enable GL_COLOR_TABLE and call glReadPixels.
     *   - Verify R=50, G≈0, B≈0.
     */

    /* Build color table: R-channel → 50; G/B channels → identity */
    GLubyte table[256*4];
    for (int i = 0; i < 256; i++) {
	table[i*4+0] = 50;           /* R always → 50 */
	table[i*4+1] = (GLubyte)i;   /* G → identity  */
	table[i*4+2] = (GLubyte)i;   /* B → identity  */
	table[i*4+3] = 255;
    }

    glColorTable(GL_COLOR_TABLE, GL_RGBA, 256, GL_RGBA, GL_UNSIGNED_BYTE, table);

    if (check_gl_error("glColorTable GL_COLOR_TABLE")) {
	fprintf(stderr, "  FAIL: glColorTable returned error\n");
	g_failed++;
	return;
    }

    /* Render a bright-red quad first (no color table yet) */
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor4ub(200, 0, 0, 255);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    /* Read back WITHOUT color table → expect (200, 0, 0) */
    GLubyte px_raw[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_raw);

    /* Now enable the color table and read again */
    glEnable(GL_COLOR_TABLE);
    GLubyte px_ct[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_ct);
    glDisable(GL_COLOR_TABLE);

    if (check_gl_error("sgi_color_table")) {
	fprintf(stderr, "  FAIL: GL error during SGI color table test\n");
	g_failed++;
	return;
    }

    /* Without color table: red ~200 */
    int raw_ok = (px_raw[0] > 150);
    /* With color table: R channel mapped to 50 regardless of input */
    int ct_ok = (px_ct[0] > 30 && px_ct[0] < 70);

    if (raw_ok && ct_ok) {
	printf("  PASS: SGI color table pixel transfer: "
	       "raw R=%d, after table R=%d (expected ~50)\n",
	       px_raw[0], px_ct[0]);
    } else {
	fprintf(stderr,
		"  FAIL: SGI color table: raw=(%d,%d,%d) after=(%d,%d,%d) "
		"(raw R expected >150, after R expected ~50)\n",
		px_raw[0], px_raw[1], px_raw[2],
		px_ct[0],  px_ct[1],  px_ct[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 11: GL_ARB_vertex_buffer_object                                */
/* ------------------------------------------------------------------ */
static void
test_vbo(int W, int H)
{
    printf("Test 11: GL_ARB_vertex_buffer_object\n");

    if (!check_ext("GL_ARB_vertex_buffer_object"))
	return;

    clear_errors();

    /* Triangle vertex data: NDC coordinates */
    GLfloat verts[] = {
	 0.0f,  0.8f,
	-0.8f, -0.8f,
	 0.8f, -0.8f,
    };
    GLfloat colors[] = {
	1.0f, 0.0f, 0.0f, 1.0f,
	0.0f, 1.0f, 0.0f, 1.0f,
	0.0f, 0.0f, 1.0f, 1.0f,
    };

    GLuint vbo[2];
    glGenBuffers(2, vbo);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);

    if (check_gl_error("VBO creation")) {
	fprintf(stderr, "  FAIL: VBO creation error\n");
	glDeleteBuffers(2, vbo);
	g_failed++;
	return;
    }

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glVertexPointer(2, GL_FLOAT, 0, NULL);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glColorPointer(4, GL_FLOAT, 0, NULL);

    glDrawArrays(GL_TRIANGLES, 0, 3);
    glFinish();

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glDeleteBuffers(2, vbo);

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/4, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("VBO render")) {
	fprintf(stderr, "  FAIL: GL error during VBO render\n");
	g_failed++;
	return;
    }

    /* The centre-bottom area of the triangle should have color */
    if (px[0] > 30 || px[1] > 30 || px[2] > 30) {
	printf("  PASS: VBO rendering produced color (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: VBO rendering produced no color at (%d,%d,%d)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 12: GL_EXT_multi_draw_arrays                                   */
/* ------------------------------------------------------------------ */
static void
test_multi_draw_arrays(int W, int H)
{
    printf("Test 12: GL_EXT_multi_draw_arrays\n");

    if (!check_ext("GL_EXT_multi_draw_arrays"))
	return;

    clear_errors();

    /* Two triangles submitted via glMultiDrawArrays */
    GLfloat verts[] = {
	/* Triangle 0 (left) */
	-0.9f,  0.0f,
	-0.1f,  0.8f,
	-0.1f, -0.8f,
	/* Triangle 1 (right) */
	 0.1f, -0.8f,
	 0.1f,  0.8f,
	 0.9f,  0.0f,
    };

    GLint  first[2]  = { 0, 3 };
    GLsizei count[2] = { 3, 3 };

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor4f(1.0f, 1.0f, 0.0f, 1.0f);

    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2, GL_FLOAT, 0, verts);
    glMultiDrawArrays(GL_TRIANGLES, first, count, 2);
    glFinish();
    glDisableClientState(GL_VERTEX_ARRAY);

    if (check_gl_error("multi_draw_arrays")) {
	fprintf(stderr, "  FAIL: GL error during multi draw arrays\n");
	g_failed++;
	return;
    }

    /* Sample from left triangle and right triangle */
    GLubyte left[4] = {0}, right[4] = {0};
    glReadPixels(W/4,   H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, left);
    glReadPixels(3*W/4, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, right);

    if ((left[0] > 100 || left[1] > 100) &&
	(right[0] > 100 || right[1] > 100)) {
	printf("  PASS: glMultiDrawArrays rendered both triangles "
	       "(L=%d,%d R=%d,%d)\n",
	       left[0], left[1], right[0], right[1]);
    } else {
	fprintf(stderr,
		"  FAIL: glMultiDrawArrays did not render both triangles "
		"(L=%d,%d R=%d,%d)\n",
		left[0], left[1], right[0], right[1]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 13: GL_ARB_depth_texture                                       */
/* ------------------------------------------------------------------ */
static void
test_depth_texture(int W, int H)
{
    printf("Test 13: GL_ARB_depth_texture\n");

    if (!check_ext("GL_ARB_depth_texture"))
	return;

    clear_errors();

    /*
     * Create a 4x4 depth texture filled with a known value (0.5).
     * Without shadow comparison (GL_TEXTURE_COMPARE_MODE = GL_NONE, the
     * default), the depth value is passed through and rendered as
     * luminance: depth=0.5 → RGBA=(127,127,127,255).
     */
    GLfloat depth_data[4*4];
    for (int i = 0; i < 16; i++)
	depth_data[i] = 0.5f;

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    /* GL_NONE mode: depth passes through as luminance (the default) */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE_ARB, GL_NONE);
    glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE_ARB, GL_LUMINANCE);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, 4, 4, 0,
		 GL_DEPTH_COMPONENT, GL_FLOAT, depth_data);

    if (check_gl_error("glTexImage2D GL_DEPTH_COMPONENT")) {
	fprintf(stderr, "  FAIL: depth texture creation failed\n");
	glDeleteTextures(1, &tex);
	g_failed++;
	return;
    }

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    draw_quad();
    glFinish();

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(1, &tex);

    if (check_gl_error("depth_texture")) {
	fprintf(stderr, "  FAIL: GL error during depth texture test\n");
	g_failed++;
	return;
    }

    /* depth=0.5 rendered as luminance → ~(127,127,127) */
    int ok = (px[0] > 110 && px[0] < 145 &&
	      px[1] > 110 && px[1] < 145 &&
	      px[2] > 110 && px[2] < 145);

    if (ok) {
	printf("  PASS: depth texture sampled as luminance: depth=0.5 → "
	       "(%d,%d,%d) ~gray\n", px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: depth texture sampled incorrectly: "
		"depth=0.5 → (%d,%d,%d), expected ~(127,127,127)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 13b: GL_ARB_depth_texture + GL_EXT_framebuffer_object         */
/* Render to an FBO that has a depth texture attached, then verify    */
/* that depth values are correctly written and readable.              */
/* ------------------------------------------------------------------ */
static void
test_fbo_depth_texture(int W, int H)
{
    printf("Test 13b: GL_ARB_depth_texture + FBO interaction\n");

    if (!check_ext("GL_ARB_depth_texture"))
	return;
    if (!check_ext("GL_EXT_framebuffer_object"))
	return;

    clear_errors();

    /* Create a depth texture (initially filled with 1.0) */
    GLuint depth_tex;
    glGenTextures(1, &depth_tex);
    glBindTexture(GL_TEXTURE_2D, depth_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, W, H, 0,
		 GL_DEPTH_COMPONENT, GL_FLOAT, NULL);

    /* Create a color texture for the FBO color attachment */
    GLuint color_tex;
    glGenTextures(1, &color_tex);
    glBindTexture(GL_TEXTURE_2D, color_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, W, H, 0,
		 GL_RGBA, GL_UNSIGNED_BYTE, NULL);

    /* Create and bind FBO */
    GLuint fbo;
    glGenFramebuffersEXT(1, &fbo);
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fbo);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
			      GL_TEXTURE_2D, depth_tex, 0);
    glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
			      GL_TEXTURE_2D, color_tex, 0);

    GLenum status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
    if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
	fprintf(stderr, "  SKIP: FBO incomplete (status=0x%x)\n",
		(unsigned)status);
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	glDeleteFramebuffersEXT(1, &fbo);
	glDeleteTextures(1, &depth_tex);
	glDeleteTextures(1, &color_tex);
	return;
    }

    /* Render a quad at z_ndc=0.5 with GL_ALWAYS depth test.
     * With the default depth range [0,1], a vertex at z_ndc=0.5
     * maps to window depth = (0.5 + 1.0) / 2.0 = 0.75.
     */
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_ALWAYS);
    glDepthMask(GL_TRUE);
    glClearDepth(1.0);
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-1.0f, -1.0f,  0.5f);
    glVertex3f( 1.0f, -1.0f,  0.5f);
    glVertex3f( 1.0f,  1.0f,  0.5f);
    glVertex3f(-1.0f,  1.0f,  0.5f);
    glEnd();
    glFinish();

    /* Read back the depth value from the FBO */
    GLfloat depth_val = 0.0f;
    glReadPixels(W/2, H/2, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &depth_val);

    glDisable(GL_DEPTH_TEST);

    /* Restore default framebuffer */
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
    glDeleteFramebuffersEXT(1, &fbo);
    glDeleteTextures(1, &depth_tex);
    glDeleteTextures(1, &color_tex);

    if (check_gl_error("test_fbo_depth_texture")) {
	fprintf(stderr, "  FAIL: GL error during FBO depth texture test\n");
	g_failed++;
	return;
    }

    /* depth=0.75 with tolerance for float precision */
    int ok = (depth_val > 0.74f && depth_val < 0.76f);
    if (ok) {
	printf("  PASS: FBO depth texture write/read: depth=%.4f (~0.75)\n",
	       depth_val);
    } else {
	fprintf(stderr,
		"  FAIL: FBO depth texture write/read: depth=%.4f, "
		"expected ~0.75\n", depth_val);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 13c: GL_ARB_framebuffer_object (no-suffix entry points)       */
/* Tests that the ARB FBO functions (without EXT suffix) work via     */
/* glGetProcAddress and produce correct results.                      */
/* ------------------------------------------------------------------ */
static void
test_arb_fbo(int W, int H)
{
    printf("Test 13c: GL_ARB_framebuffer_object\n");

    if (!check_ext("GL_ARB_framebuffer_object"))
	return;

    clear_errors();

    /* Look up ARB entry points (no-suffix) via glGetProcAddress */
    typedef GLboolean (APIENTRY *PFNISRENDERBUFFER)(GLuint);
    typedef void (APIENTRY *PFNBINDRENDERBUFFER)(GLenum, GLuint);
    typedef void (APIENTRY *PFNDELETERENDERBUFFERS)(GLsizei, const GLuint *);
    typedef void (APIENTRY *PFNGENRENDERBUFFERS)(GLsizei, GLuint *);
    typedef void (APIENTRY *PFNRENDERBUFFERSTORAGE)(GLenum, GLenum, GLsizei, GLsizei);
    typedef GLboolean (APIENTRY *PFNISFRAMEBUFFER)(GLuint);
    typedef void (APIENTRY *PFNBINDFRAMEBUFFER)(GLenum, GLuint);
    typedef void (APIENTRY *PFNDELETEFRAMEBUFFERS)(GLsizei, const GLuint *);
    typedef void (APIENTRY *PFNGENFRAMEBUFFERS)(GLsizei, GLuint *);
    typedef GLenum (APIENTRY *PFNCHECKFRAMEBUFFERSTATUS)(GLenum);
    typedef void (APIENTRY *PFNFRAMEBUFFERTEXTURE2D)(GLenum, GLenum, GLenum, GLuint, GLint);
    typedef void (APIENTRY *PFNFRAMEBUFFERRENDERBUFFER)(GLenum, GLenum, GLenum, GLuint);
    typedef void (APIENTRY *PFNGENERATEMIPMAP)(GLenum);
    typedef void (APIENTRY *PFNRENDERBUFFERSTORAGEMULTISAMPLE)(GLenum, GLsizei, GLenum, GLsizei, GLsizei);

    PFNISRENDERBUFFER pIsRenderbuffer =
	(PFNISRENDERBUFFER) OSMesaGetProcAddress("glIsRenderbuffer");
    PFNBINDRENDERBUFFER pBindRenderbuffer =
	(PFNBINDRENDERBUFFER) OSMesaGetProcAddress("glBindRenderbuffer");
    PFNDELETERENDERBUFFERS pDeleteRenderbuffers =
	(PFNDELETERENDERBUFFERS) OSMesaGetProcAddress("glDeleteRenderbuffers");
    PFNGENRENDERBUFFERS pGenRenderbuffers =
	(PFNGENRENDERBUFFERS) OSMesaGetProcAddress("glGenRenderbuffers");
    PFNRENDERBUFFERSTORAGE pRenderbufferStorage =
	(PFNRENDERBUFFERSTORAGE) OSMesaGetProcAddress("glRenderbufferStorage");
    PFNISFRAMEBUFFER pIsFramebuffer =
	(PFNISFRAMEBUFFER) OSMesaGetProcAddress("glIsFramebuffer");
    PFNBINDFRAMEBUFFER pBindFramebuffer =
	(PFNBINDFRAMEBUFFER) OSMesaGetProcAddress("glBindFramebuffer");
    PFNDELETEFRAMEBUFFERS pDeleteFramebuffers =
	(PFNDELETEFRAMEBUFFERS) OSMesaGetProcAddress("glDeleteFramebuffers");
    PFNGENFRAMEBUFFERS pGenFramebuffers =
	(PFNGENFRAMEBUFFERS) OSMesaGetProcAddress("glGenFramebuffers");
    PFNCHECKFRAMEBUFFERSTATUS pCheckFramebufferStatus =
	(PFNCHECKFRAMEBUFFERSTATUS) OSMesaGetProcAddress("glCheckFramebufferStatus");
    PFNFRAMEBUFFERTEXTURE2D pFramebufferTexture2D =
	(PFNFRAMEBUFFERTEXTURE2D) OSMesaGetProcAddress("glFramebufferTexture2D");
    PFNFRAMEBUFFERRENDERBUFFER pFramebufferRenderbuffer =
	(PFNFRAMEBUFFERRENDERBUFFER) OSMesaGetProcAddress("glFramebufferRenderbuffer");
    PFNGENERATEMIPMAP pGenerateMipmap =
	(PFNGENERATEMIPMAP) OSMesaGetProcAddress("glGenerateMipmap");
    PFNRENDERBUFFERSTORAGEMULTISAMPLE pRenderbufferStorageMultisample =
	(PFNRENDERBUFFERSTORAGEMULTISAMPLE) OSMesaGetProcAddress("glRenderbufferStorageMultisample");

    if (!pIsRenderbuffer || !pBindRenderbuffer || !pDeleteRenderbuffers ||
	!pGenRenderbuffers || !pRenderbufferStorage || !pIsFramebuffer ||
	!pBindFramebuffer || !pDeleteFramebuffers || !pGenFramebuffers ||
	!pCheckFramebufferStatus || !pFramebufferTexture2D ||
	!pFramebufferRenderbuffer || !pGenerateMipmap ||
	!pRenderbufferStorageMultisample) {
	fprintf(stderr, "  FAIL: one or more ARB FBO entry points not found\n");
	g_failed++;
	return;
    }

    /* Create and bind a framebuffer using ARB no-suffix entry points */
    GLuint fbo, rbo_color, rbo_depth;

    pGenFramebuffers(1, &fbo);
    pGenRenderbuffers(1, &rbo_color);
    pGenRenderbuffers(1, &rbo_depth);

    /*
     * Per GL_ARB_framebuffer_object: Is* must return FALSE for names that
     * have been Gen'd but never yet Bind'd (they are not objects yet).
     */
    if (pIsFramebuffer(fbo) || pIsRenderbuffer(rbo_color) ||
	pIsRenderbuffer(rbo_depth)) {
	fprintf(stderr,
		"  FAIL: Is* returned TRUE for gen-but-never-bound names "
		"(should be FALSE per ARB spec)\n");
	g_failed++;
	pDeleteFramebuffers(1, &fbo);
	pDeleteRenderbuffers(1, &rbo_color);
	pDeleteRenderbuffers(1, &rbo_depth);
	return;
    }

    /* After binding, Is* must return TRUE */
    pBindFramebuffer(GL_FRAMEBUFFER_EXT, fbo);
    pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_color);
    if (!pIsFramebuffer(fbo) || !pIsRenderbuffer(rbo_color)) {
	fprintf(stderr,
		"  FAIL: Is* returned FALSE after bind (should be TRUE)\n");
	g_failed++;
	pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	pDeleteFramebuffers(1, &fbo);
	pDeleteRenderbuffers(1, &rbo_color);
	pDeleteRenderbuffers(1, &rbo_depth);
	return;
    }
    pRenderbufferStorage(GL_RENDERBUFFER_EXT, GL_RGBA, W, H);
    pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
			     GL_RENDERBUFFER_EXT, rbo_color);

    pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_depth);
    pRenderbufferStorage(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, W, H);
    pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
			     GL_RENDERBUFFER_EXT, rbo_depth);

    GLenum status = pCheckFramebufferStatus(GL_FRAMEBUFFER_EXT);
    if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
	fprintf(stderr, "  FAIL: FBO incomplete (status=0x%x)\n",
		(unsigned)status);
	g_failed++;
	pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	pDeleteFramebuffers(1, &fbo);
	pDeleteRenderbuffers(1, &rbo_color);
	pDeleteRenderbuffers(1, &rbo_depth);
	return;
    }

    /* Render a solid red quad into the FBO */
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();

    /* Read back a pixel and verify it is red */
    GLubyte pixel[4];
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, pixel);
    if (pixel[0] < 200 || pixel[1] > 10 || pixel[2] > 10) {
	fprintf(stderr, "  FAIL: expected red pixel, got (%d,%d,%d)\n",
		pixel[0], pixel[1], pixel[2]);
	g_failed++;
    } else {
	printf("  PASS: ARB FBO entry points work correctly\n");
    }

    /* Query GL_MAX_SAMPLES and verify it is at least 1 */
    GLint max_samples = 0;
    glGetIntegerv(GL_MAX_SAMPLES, &max_samples);
    if (max_samples < 1) {
	fprintf(stderr, "  FAIL: GL_MAX_SAMPLES=%d, expected >= 1\n",
		max_samples);
	g_failed++;
    }

    /* Test glRenderbufferStorageMultisample with samples=0 (always valid) */
    GLuint rbo_ms;
    pGenRenderbuffers(1, &rbo_ms);
    pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_ms);
    pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 0, GL_RGBA, W, H);
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
	fprintf(stderr, "  FAIL: RenderbufferStorageMultisample(samples=0) returned error 0x%x\n",
		err);
	g_failed++;
    }

    /* Test glRenderbufferStorageMultisample with samples=1 (now valid) */
    pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 1, GL_RGBA, W, H);
    err = glGetError();
    if (err != GL_NO_ERROR) {
	fprintf(stderr, "  FAIL: RenderbufferStorageMultisample(samples=1) returned error 0x%x\n",
		err);
	g_failed++;
    } else {
	/* Verify GL_RENDERBUFFER_SAMPLES reports 1 */
	typedef void (APIENTRY *PFNGETRENDERBUFFERPARAMETERIV)(GLenum, GLenum, GLint *);
	PFNGETRENDERBUFFERPARAMETERIV pGetRenderbufferParameteriv =
	    (PFNGETRENDERBUFFERPARAMETERIV) OSMesaGetProcAddress("glGetRenderbufferParameteriv");
	if (pGetRenderbufferParameteriv) {
	    GLint nsamples = 0;
	    pGetRenderbufferParameteriv(GL_RENDERBUFFER_EXT,
				       GL_RENDERBUFFER_SAMPLES, &nsamples);
	    if (nsamples != 1) {
		fprintf(stderr,
			"  FAIL: GL_RENDERBUFFER_SAMPLES=%d, expected 1\n",
			nsamples);
		g_failed++;
	    } else {
		printf("  PASS: RenderbufferStorageMultisample(samples=1) works\n");
	    }
	}
    }

    /* samples > GL_MAX_SAMPLES should still return GL_INVALID_VALUE */
    pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, max_samples + 1,
				    GL_RGBA, W, H);
    err = glGetError();
    if (err != GL_INVALID_VALUE) {
	fprintf(stderr,
		"  FAIL: RenderbufferStorageMultisample(samples=%d) should "
		"return GL_INVALID_VALUE, got 0x%x\n",
		max_samples + 1, err);
	g_failed++;
    }
    pDeleteRenderbuffers(1, &rbo_ms);

    /* --- Test: mismatched attachment dimensions must not break FBO --- */
    {
	typedef void (APIENTRY *PFNGETFRAMEBUFFERATTACHMENTPARAMIV)(GLenum, GLenum, GLenum, GLint *);
	PFNGETFRAMEBUFFERATTACHMENTPARAMIV pGetFBAttach =
	    (PFNGETFRAMEBUFFERATTACHMENTPARAMIV)
	    OSMesaGetProcAddress("glGetFramebufferAttachmentParameteriv");

	/* Create a new FBO with color (WxH) and depth (W/2 x H/2) */
	GLuint fbo2, rbo_c2, rbo_d2;
	pGenFramebuffers(1, &fbo2);
	pGenRenderbuffers(1, &rbo_c2);
	pGenRenderbuffers(1, &rbo_d2);

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, fbo2);
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_c2);
	pRenderbufferStorage(GL_RENDERBUFFER_EXT, GL_RGBA, W, H);
	pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
				 GL_RENDERBUFFER_EXT, rbo_c2);

	pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_d2);
	pRenderbufferStorage(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, W / 2, H / 2);
	pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
				 GL_RENDERBUFFER_EXT, rbo_d2);

	GLenum st2 = pCheckFramebufferStatus(GL_FRAMEBUFFER_EXT);
	if (st2 != GL_FRAMEBUFFER_COMPLETE_EXT) {
	    fprintf(stderr,
		    "  FAIL: FBO with mismatched attachment sizes incomplete "
		    "(status=0x%x); ARB_FBO allows mismatched sizes\n",
		    (unsigned)st2);
	    g_failed++;
	} else {
	    printf("  PASS: FBO with mismatched attachment sizes is complete\n");
	}
	clear_errors();

	/* Test GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE on the color attachment */
	if (pGetFBAttach) {
	    GLint red_bits = -1;
	    pGetFBAttach(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
			 GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE, &red_bits);
	    err = glGetError();
	    if (err != GL_NO_ERROR || red_bits < 1) {
		fprintf(stderr,
			"  FAIL: GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE=%d err=0x%x\n",
			red_bits, err);
		g_failed++;
	    } else {
		printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE = %d\n",
		       red_bits);
	    }

	    /* Test GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING */
	    GLint enc = -1;
	    pGetFBAttach(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
			 GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING, &enc);
	    err = glGetError();
	    if (err != GL_NO_ERROR || enc != GL_LINEAR) {
		fprintf(stderr,
			"  FAIL: GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING=0x%x "
			"(expected GL_LINEAR=0x%x) err=0x%x\n",
			enc, GL_LINEAR, err);
		g_failed++;
	    } else {
		printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = "
		       "GL_LINEAR\n");
	    }

	    /* Test GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE */
	    GLint comp = -1;
	    pGetFBAttach(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
			 GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE, &comp);
	    err = glGetError();
	    if (err != GL_NO_ERROR || comp != GL_UNSIGNED_NORMALIZED) {
		fprintf(stderr,
			"  FAIL: GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE=0x%x "
			"err=0x%x\n", comp, err);
		g_failed++;
	    } else {
		printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = "
		       "GL_UNSIGNED_NORMALIZED\n");
	    }

	    /* Test GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE on depth attachment */
	    GLint depth_bits = -1;
	    pGetFBAttach(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
			 GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE, &depth_bits);
	    err = glGetError();
	    if (err != GL_NO_ERROR || depth_bits < 1) {
		fprintf(stderr,
			"  FAIL: GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE=%d "
			"err=0x%x\n", depth_bits, err);
		g_failed++;
	    } else {
		printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = %d\n",
		       depth_bits);
	    }

	    /* Default framebuffer: query GL_BACK_LEFT color encoding */
	    pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	    GLint dflt_enc = -1;
	    pGetFBAttach(GL_FRAMEBUFFER_EXT, GL_BACK_LEFT,
			 GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING, &dflt_enc);
	    err = glGetError();
	    if (err != GL_NO_ERROR) {
		fprintf(stderr,
			"  FAIL: default FBO GL_BACK_LEFT query error 0x%x\n",
			err);
		g_failed++;
	    } else {
		printf("  PASS: default FBO GL_BACK_LEFT query succeeded\n");
	    }
	    pBindFramebuffer(GL_FRAMEBUFFER_EXT, fbo2);
	}

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	pDeleteFramebuffers(1, &fbo2);
	pDeleteRenderbuffers(1, &rbo_c2);
	pDeleteRenderbuffers(1, &rbo_d2);
    }

    /* --- Test: GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE when sample counts differ --- */
    if (max_samples >= 1) {
	GLuint fbo3, rbo_c3, rbo_d3;
	pGenFramebuffers(1, &fbo3);
	pGenRenderbuffers(1, &rbo_c3);
	pGenRenderbuffers(1, &rbo_d3);

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, fbo3);

	/* color: samples=1 */
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_c3);
	pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 1, GL_RGBA, W, H);
	pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_COLOR_ATTACHMENT0_EXT,
				 GL_RENDERBUFFER_EXT, rbo_c3);

	/* depth: samples=0 (mismatch!) */
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_d3);
	pRenderbufferStorage(GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, W, H);
	pFramebufferRenderbuffer(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT,
				 GL_RENDERBUFFER_EXT, rbo_d3);

	GLenum st3 = pCheckFramebufferStatus(GL_FRAMEBUFFER_EXT);
	if (st3 != GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE) {
	    fprintf(stderr,
		    "  FAIL: mixed sample counts should yield "
		    "GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE, got 0x%x\n",
		    (unsigned)st3);
	    g_failed++;
	} else {
	    printf("  PASS: mixed sample counts -> "
		   "GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE\n");
	}
	clear_errors();

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	pDeleteFramebuffers(1, &fbo3);
	pDeleteRenderbuffers(1, &rbo_c3);
	pDeleteRenderbuffers(1, &rbo_d3);
    }

    /* --- Test: IsRenderbuffer / IsFramebuffer on gen'd-but-never-bound names --- */
    {
	GLuint unbound_rb, unbound_fb;
	pGenRenderbuffers(1, &unbound_rb);
	pGenFramebuffers(1, &unbound_fb);

	/* Spec: glIs* returns FALSE until the name has been bound at least once */
	if (pIsRenderbuffer(unbound_rb)) {
	    fprintf(stderr,
		    "  FAIL: glIsRenderbuffer returned TRUE for gen-but-never-"
		    "bound name %u\n", unbound_rb);
	    g_failed++;
	} else {
	    printf("  PASS: glIsRenderbuffer returns FALSE for unbound name\n");
	}

	if (pIsFramebuffer(unbound_fb)) {
	    fprintf(stderr,
		    "  FAIL: glIsFramebuffer returned TRUE for gen-but-never-"
		    "bound name %u\n", unbound_fb);
	    g_failed++;
	} else {
	    printf("  PASS: glIsFramebuffer returns FALSE for unbound name\n");
	}

	/* After binding, they must return TRUE */
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, unbound_rb);
	if (!pIsRenderbuffer(unbound_rb)) {
	    fprintf(stderr,
		    "  FAIL: glIsRenderbuffer returned FALSE after bind\n");
	    g_failed++;
	} else {
	    printf("  PASS: glIsRenderbuffer returns TRUE after bind\n");
	}

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, unbound_fb);
	if (!pIsFramebuffer(unbound_fb)) {
	    fprintf(stderr,
		    "  FAIL: glIsFramebuffer returned FALSE after bind\n");
	    g_failed++;
	} else {
	    printf("  PASS: glIsFramebuffer returns TRUE after bind\n");
	}

	pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, 0);
	pDeleteFramebuffers(1, &unbound_fb);
	pDeleteRenderbuffers(1, &unbound_rb);
	clear_errors();
    }

    /* --- Test: RenderbufferStorageMultisample NumSamples not clobbered by
     *          a prior unrelated GL error (ctx->ErrorValue fragility fix)    --- */
    {
	GLuint rbo_err;
	pGenRenderbuffers(1, &rbo_err);
	pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_err);

	/* Poison the error state with an unrelated error */
	glEnable(0xDEAD);
	/* Now successfully allocate multisample storage */
	pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 0, GL_RGBA, W, H);

	/* Clear the unrelated error */
	(void)glGetError();
	(void)glGetError();

	typedef void (APIENTRY *PFNGETRENDERBUFFERPARAMIV)(GLenum, GLenum, GLint *);
	PFNGETRENDERBUFFERPARAMIV pGetRBParam =
	    (PFNGETRENDERBUFFERPARAMIV)
	    OSMesaGetProcAddress("glGetRenderbufferParameteriv");
	if (pGetRBParam) {
	    GLint s = -1;
	    pGetRBParam(GL_RENDERBUFFER_EXT, GL_RENDERBUFFER_SAMPLES, &s);
	    if (s != 0) {
		fprintf(stderr,
			"  FAIL: NumSamples=%d after multisample storage with "
			"prior error; expected 0\n", s);
		g_failed++;
	    } else {
		printf("  PASS: RenderbufferStorageMultisample NumSamples "
		       "correct despite prior error\n");
	    }
	}
	pDeleteRenderbuffers(1, &rbo_err);
	clear_errors();
    }

    /* --- Test: RenderbufferStorageMultisample NumSamples not set when
     *          call fails due to invalid internal format (same dimensions,
     *          invalid format → INVALID_ENUM should not update NumSamples) --- */
    {
	typedef void (APIENTRY *PFNGETRENDERBUFFERPARAMIV)(GLenum, GLenum, GLint *);
	PFNGETRENDERBUFFERPARAMIV pGetRBParam =
	    (PFNGETRENDERBUFFERPARAMIV)
	    OSMesaGetProcAddress("glGetRenderbufferParameteriv");
	if (pGetRBParam) {
	    GLuint rbo_bad;
	    GLint s = -1;

	    pGenRenderbuffers(1, &rbo_bad);
	    pBindRenderbuffer(GL_RENDERBUFFER_EXT, rbo_bad);

	    /* First: valid allocation with samples=0 at W x H */
	    pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 0, GL_RGBA, W, H);
	    (void)glGetError();

	    /* Second: same dimensions, same samples, but INVALID format.
	     * NumSamples must remain at 0 (not updated to 1). */
	    pRenderbufferStorageMultisample(GL_RENDERBUFFER_EXT, 1,
					   0xDEAD /* invalid format */, W, H);
	    (void)glGetError(); /* consume the GL_INVALID_ENUM */

	    s = -1;
	    pGetRBParam(GL_RENDERBUFFER_EXT, GL_RENDERBUFFER_SAMPLES, &s);
	    if (s != 0) {
		fprintf(stderr,
			"  FAIL: NumSamples=%d after failed multisample alloc "
			"(invalid format, same dims); expected 0\n", s);
		g_failed++;
	    } else {
		printf("  PASS: RenderbufferStorageMultisample NumSamples "
		       "unchanged after failed alloc (invalid format)\n");
	    }
	    pDeleteRenderbuffers(1, &rbo_bad);
	    clear_errors();
	}
    }

    /* Cleanup */
    pBindFramebuffer(GL_FRAMEBUFFER_EXT, 0);
    pDeleteFramebuffers(1, &fbo);
    pDeleteRenderbuffers(1, &rbo_color);
    pDeleteRenderbuffers(1, &rbo_depth);
}

/* ------------------------------------------------------------------ */
/* Test 14: GL_ARB_shadow                                              */
/* ------------------------------------------------------------------ */
static void
test_shadow(int W, int H)
{
    printf("Test 14: GL_ARB_shadow\n");

    if (!check_ext("GL_ARB_shadow"))
	return;

    clear_errors();

    /*
     * Create a depth texture and fill it with a known depth value (0.5).
     * Enable shadow comparison (GL_COMPARE_R_TO_TEXTURE_ARB, GL_LEQUAL).
     * When the texture coordinate R <= stored depth → result = 1.0 (lit).
     * When R > stored depth → result = 0.0 (in shadow).
     */
    GLuint depth_tex;
    glGenTextures(1, &depth_tex);
    glBindTexture(GL_TEXTURE_2D, depth_tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    /* Set comparison mode */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE_ARB,
		    GL_COMPARE_R_TO_TEXTURE_ARB);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL);

    /* Fill a 4x4 depth texture with 0.5 */
    GLfloat depth_data[4*4];
    for (int i = 0; i < 16; i++)
	depth_data[i] = 0.5f;

    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, 4, 4, 0,
		 GL_DEPTH_COMPONENT, GL_FLOAT, depth_data);

    if (check_gl_error("shadow depth texture creation")) {
	fprintf(stderr, "  FAIL: shadow depth texture creation failed\n");
	glDeleteTextures(1, &depth_tex);
	g_failed++;
	return;
    }

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    /*
     * First pass: R=0.3 → 0.3 <= 0.5 → comparison passes → result=1 (white)
     */
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glTexCoord3f(0.5f, 0.5f, 0.3f); glVertex2f(-1.0f, -1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.3f); glVertex2f( 1.0f, -1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.3f); glVertex2f( 1.0f,  1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.3f); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px_lit[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_lit);

    /*
     * Second pass: R=0.8 → 0.8 > 0.5 → comparison fails → result=0 (black)
     */
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glTexCoord3f(0.5f, 0.5f, 0.8f); glVertex2f(-1.0f, -1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.8f); glVertex2f( 1.0f, -1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.8f); glVertex2f( 1.0f,  1.0f);
    glTexCoord3f(0.5f, 0.5f, 0.8f); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px_shadow[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_shadow);

    glDisable(GL_TEXTURE_2D);
    glDeleteTextures(1, &depth_tex);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

    if (check_gl_error("shadow")) {
	fprintf(stderr, "  FAIL: GL error during shadow test\n");
	g_failed++;
	return;
    }

    /* Lit pass: all channels should be high (white) */
    int lit_ok     = (px_lit[0]    > 150);
    /* Shadow pass: all channels should be low (black) */
    int shadow_ok  = (px_shadow[0] < 100);

    if (lit_ok && shadow_ok) {
	printf("  PASS: shadow comparison lit=%d shadow=%d\n",
	       px_lit[0], px_shadow[0]);
    } else {
	fprintf(stderr,
		"  FAIL: shadow comparison lit=%d (expected >150) "
		"shadow=%d (expected <100)\n",
		px_lit[0], px_shadow[0]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 15: GL_EXT_texture_rectangle                                   */
/* ------------------------------------------------------------------ */
static void
test_texture_rectangle(int W, int H)
{
    printf("Test 15: GL_EXT_texture_rectangle\n");

    /* Either EXT or ARB flavor is fine */
    const char *exts = (const char *)glGetString(GL_EXTENSIONS);
    if (!exts ||
	(!strstr(exts, "GL_EXT_texture_rectangle") &&
	 !strstr(exts, "GL_ARB_texture_rectangle") &&
	 !strstr(exts, "GL_NV_texture_rectangle"))) {
	fprintf(stderr, "  SKIP: GL_EXT_texture_rectangle not advertised\n");
	return;
    }

    clear_errors();

    int TW = 4, TH = 4;

    /* Fill texture with a gradient: row 0 = red .. row 3 = blue */
    GLubyte data[4*4*4];
    for (int y = 0; y < TH; y++) {
	for (int x = 0; x < TW; x++) {
	    int idx = (y*TW + x)*4;
	    data[idx+0] = (GLubyte)(255 - y*64);
	    data[idx+1] = 0;
	    data[idx+2] = (GLubyte)(y*64);
	    data[idx+3] = 255;
	}
    }

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_RECTANGLE_ARB, tex);
    glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    /* Rectangle textures do not support mipmaps or most wrap modes */
    glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGBA, TW, TH, 0,
		 GL_RGBA, GL_UNSIGNED_BYTE, data);

    if (check_gl_error("glTexImage2D GL_TEXTURE_RECTANGLE_ARB")) {
	fprintf(stderr, "  FAIL: rectangle texture creation failed\n");
	glDeleteTextures(1, &tex);
	g_failed++;
	return;
    }

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_TEXTURE_RECTANGLE_ARB);
    glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    /* Rectangle textures use integer (pixel) coordinates, not [0,1] */
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    /* Use non-normalized coords (0..TW, 0..TH) */
    glTexCoord2f(0.0f,  0.0f); glVertex2f(-1.0f, -1.0f);
    glTexCoord2f((float)TW, 0.0f); glVertex2f( 1.0f, -1.0f);
    glTexCoord2f((float)TW, (float)TH); glVertex2f( 1.0f,  1.0f);
    glTexCoord2f(0.0f,  (float)TH); glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    GLubyte px_bot[4] = {0};
    glReadPixels(W/2, 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px_bot);

    glDisable(GL_TEXTURE_RECTANGLE_ARB);
    glDeleteTextures(1, &tex);

    if (check_gl_error("texture_rectangle")) {
	fprintf(stderr, "  FAIL: GL error during texture rectangle test\n");
	g_failed++;
	return;
    }

    /* Bottom of screen → row 0 texels → red dominant */
    if (px_bot[0] > 150 && px_bot[2] < 100) {
	printf("  PASS: rectangle texture bottom row red (%d,%d,%d)\n",
	       px_bot[0], px_bot[1], px_bot[2]);
    } else {
	fprintf(stderr,
		"  FAIL: rectangle texture bottom row expected red, "
		"got (%d,%d,%d)\n",
		px_bot[0], px_bot[1], px_bot[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 16: GL_ARB_vertex_program                                      */
/* ------------------------------------------------------------------ */
static void
test_vertex_program(int W, int H)
{
    printf("Test 16: GL_ARB_vertex_program\n");

    if (!check_ext("GL_ARB_vertex_program"))
	return;

    clear_errors();

    /* Minimal ARB vertex program that passes position through */
    static const char vp_src[] =
	"!!ARBvp1.0\n"
	"ATTRIB iPos = vertex.position;\n"
	"OUTPUT oPos = result.position;\n"
	"MOV oPos, iPos;\n"
	"MOV result.color, {1.0, 0.5, 0.0, 1.0};\n"
	"END\n";

    GLuint vp;
    glGenProgramsARB(1, &vp);
    glBindProgramARB(GL_VERTEX_PROGRAM_ARB, vp);
    glProgramStringARB(GL_VERTEX_PROGRAM_ARB, GL_PROGRAM_FORMAT_ASCII_ARB,
		       (GLsizei)strlen(vp_src), vp_src);

    GLint errPos = -1;
    glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &errPos);
    if (errPos != -1) {
	const GLubyte *errStr = glGetString(GL_PROGRAM_ERROR_STRING_ARB);
	fprintf(stderr, "  FAIL: ARB vertex program error at %d: %s\n",
		errPos, errStr ? (const char *)errStr : "(null)");
	glDeleteProgramsARB(1, &vp);
	g_failed++;
	return;
    }

    glEnable(GL_VERTEX_PROGRAM_ARB);
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_TRIANGLES);
    glVertex2f( 0.0f,  0.8f);
    glVertex2f(-0.8f, -0.8f);
    glVertex2f( 0.8f, -0.8f);
    glEnd();
    glFinish();

    glDisable(GL_VERTEX_PROGRAM_ARB);
    glDeleteProgramsARB(1, &vp);

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/4, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("vertex_program")) {
	fprintf(stderr, "  FAIL: GL error during vertex program test\n");
	g_failed++;
	return;
    }

    /* Program outputs orange (1.0, 0.5, 0.0) */
    if (px[0] > 200 && px[1] > 80 && px[2] < 50) {
	printf("  PASS: ARB vertex program output orange (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: ARB vertex program output (%d,%d,%d) "
		"expected ~(255,127,0)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 17: GL_ARB_fragment_program                                    */
/* ------------------------------------------------------------------ */
static void
test_fragment_program(int W, int H)
{
    printf("Test 17: GL_ARB_fragment_program\n");

    if (!check_ext("GL_ARB_fragment_program"))
	return;

    clear_errors();

    /* Minimal ARB fragment program that outputs a fixed cyan color */
    static const char fp_src[] =
	"!!ARBfp1.0\n"
	"MOV result.color, {0.0, 1.0, 1.0, 1.0};\n"
	"END\n";

    GLuint fp;
    glGenProgramsARB(1, &fp);
    glBindProgramARB(GL_FRAGMENT_PROGRAM_ARB, fp);
    glProgramStringARB(GL_FRAGMENT_PROGRAM_ARB, GL_PROGRAM_FORMAT_ASCII_ARB,
		       (GLsizei)strlen(fp_src), fp_src);

    GLint errPos = -1;
    glGetIntegerv(GL_PROGRAM_ERROR_POSITION_ARB, &errPos);
    if (errPos != -1) {
	const GLubyte *errStr = glGetString(GL_PROGRAM_ERROR_STRING_ARB);
	fprintf(stderr, "  FAIL: ARB fragment program error at %d: %s\n",
		errPos, errStr ? (const char *)errStr : "(null)");
	glDeleteProgramsARB(1, &fp);
	g_failed++;
	return;
    }

    glEnable(GL_FRAGMENT_PROGRAM_ARB);
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    glDisable(GL_FRAGMENT_PROGRAM_ARB);
    glDeleteProgramsARB(1, &fp);

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("fragment_program")) {
	fprintf(stderr, "  FAIL: GL error during fragment program test\n");
	g_failed++;
	return;
    }

    /* Program outputs cyan (0.0, 1.0, 1.0) */
    if (px[0] < 50 && px[1] > 200 && px[2] > 200) {
	printf("  PASS: ARB fragment program output cyan (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: ARB fragment program output (%d,%d,%d) "
		"expected ~(0,255,255)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18: GL_ARB_shader_objects / GL_ARB_vertex_shader               */
/* ------------------------------------------------------------------ */
static void
test_glsl_shader(int W, int H)
{
    printf("Test 18: GL_ARB_shader_objects / GL_ARB_vertex_shader\n");

    if (!check_ext("GL_ARB_shader_objects") ||
	!check_ext("GL_ARB_vertex_shader"))
	return;

    clear_errors();

    const char *vert =
	"#version 110\n"
	"void main() {\n"
	"    gl_Position = gl_Vertex;\n"
	"    gl_FrontColor = gl_Color;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"void main() {\n"
	"    gl_FragColor = gl_Color;\n"
	"}\n";

    GLuint prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: GLSL program compilation/link failed\n");
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor4f(0.0f, 0.0f, 1.0f, 1.0f);   /* blue via vertex color */
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();

    glUseProgram(0);
    glDeleteProgram(prog);

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("glsl_shader")) {
	fprintf(stderr, "  FAIL: GL error during GLSL shader test\n");
	g_failed++;
	return;
    }

    if (px[0] < 50 && px[1] < 50 && px[2] > 200) {
	printf("  PASS: GLSL shader output blue (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: GLSL shader output (%d,%d,%d) expected ~(0,0,255)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18aa: GLSL variable uniform-array indexing                     */
/* ------------------------------------------------------------------ */
static void
test_glsl_uniform_array_index(int W, int H)
{
    const char *vert =
	"#version 110\n"
	"void main() { gl_Position = gl_Vertex; }\n";
    const char *fragSingle =
	"#version 110\n"
	"uniform vec4 colors[2];\n"
	"uniform int choice;\n"
	"void main() { gl_FragColor = colors[choice]; }\n";
    const char *fragPair =
	"#version 110\n"
	"uniform vec4 colors[2];\n"
	"uniform int first;\n"
	"uniform int second;\n"
	"void main() { gl_FragColor = colors[first] + colors[second]; }\n";
    const GLfloat colors[8] = {
	1.0f, 0.0f, 0.0f, 1.0f,
	0.0f, 1.0f, 0.0f, 1.0f
    };
    GLubyte px[4] = {0};
    GLuint prog;
    GLint colorsLoc;
    GLint colorsBaseLoc;
    GLint choiceLoc;

    printf("Test 18aa: GLSL variable uniform-array indexing\n");
    prog = make_program(vert, fragSingle);
    if (!prog) {
	fprintf(stderr, "  FAIL: uniform-array program compilation/link failed\n");
	g_failed++;
	return;
    }

    colorsLoc = glGetUniformLocation(prog, "colors[0]");
    colorsBaseLoc = glGetUniformLocation(prog, "colors");
    choiceLoc = glGetUniformLocation(prog, "choice");
    if (colorsLoc < 0 || colorsBaseLoc != colorsLoc || choiceLoc < 0) {
	fprintf(stderr,
		"  FAIL: uniform-array locations unavailable "
		"(colors[0]=%d, colors=%d, choice=%d)\n",
		colorsLoc, colorsBaseLoc, choiceLoc);
	glDeleteProgram(prog);
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glUniform4fv(colorsLoc, 2, colors);
    glUniform1i(choiceLoc, 1);
    glViewport(0, 0, W, H);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();
    glUseProgram(0);
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_uniform_array_index")) {
	fprintf(stderr, "  FAIL: GL error during uniform-array indexing\n");
	g_failed++;
    } else if (px[0] < 50 && px[1] > 200 && px[2] < 50) {
	printf("  PASS: variable index selected green array element\n");
    } else {
	fprintf(stderr,
		"  FAIL: variable index output (%d,%d,%d), expected green\n",
		px[0], px[1], px[2]);
	g_failed++;
    }

    prog = make_program(vert, fragPair);
    if (!prog) {
	fprintf(stderr,
		"  FAIL: paired uniform-array program compilation/link failed\n");
	g_failed++;
	return;
    }

    colorsLoc = glGetUniformLocation(prog, "colors[0]");
    colorsBaseLoc = glGetUniformLocation(prog, "colors");
    {
	GLint firstLoc = glGetUniformLocation(prog, "first");
	GLint secondLoc = glGetUniformLocation(prog, "second");
	if (colorsLoc < 0 || colorsBaseLoc != colorsLoc ||
	    firstLoc < 0 || secondLoc < 0) {
	    fprintf(stderr,
		    "  FAIL: paired uniform-array locations unavailable "
		    "(colors[0]=%d, colors=%d, first=%d, second=%d)\n",
		    colorsLoc, colorsBaseLoc, firstLoc, secondLoc);
	    glDeleteProgram(prog);
	    g_failed++;
	    return;
	}

	glUseProgram(prog);
	glUniform4fv(colorsLoc, 2, colors);
	glUniform1i(firstLoc, 0);
	glUniform1i(secondLoc, 1);
    }
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();
    glUseProgram(0);
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_uniform_array_pair")) {
	fprintf(stderr, "  FAIL: GL error during paired array indexing\n");
	g_failed++;
    } else if (px[0] > 200 && px[1] > 200 && px[2] < 50) {
	printf("  PASS: independent variable indices produced yellow\n");
    } else {
	fprintf(stderr,
		"  FAIL: paired index output (%d,%d,%d), expected yellow\n",
		px[0], px[1], px[2]);
	g_failed++;
    }

    {
	const char *fragLighting =
	    "#version 110\n"
	    "uniform int count;\n"
	    "uniform int kinds[2];\n"
	    "uniform vec3 directions[2];\n"
	    "uniform vec3 lightColors[2];\n"
	    "void main() {\n"
	    "  vec3 n = vec3(0.0, 0.0, 1.0);\n"
	    "  vec3 color = vec3(0.25);\n"
	    "  for (int i = 0; i < 2; i++) {\n"
	    "    if (i >= count) break;\n"
	    "    if (kinds[i] == 0) {\n"
	    "      vec3 l = normalize(directions[i]);\n"
	    "      color += lightColors[i] *\n"
	    "               (max(0.0, dot(n, l)) * 0.75);\n"
	    "    }\n"
	    "  }\n"
	    "  gl_FragColor = vec4(color, 1.0);\n"
	    "}\n";
	const GLint kinds[2] = {0, 0};
	const GLfloat directions[6] = {0, 0, 1,  1, 0, 0};
	const GLfloat lightColors[6] = {1, 1, 1,  0, 0, 0};
	GLint countLoc;
	GLint kindsLoc;
	GLint directionsLoc;
	GLint lightColorsLoc;

	prog = make_program(vert, fragLighting);
	if (!prog) {
	    fprintf(stderr,
		    "  FAIL: lighting-array program compilation/link failed\n");
	    g_failed++;
	    return;
	}
	countLoc = glGetUniformLocation(prog, "count");
	kindsLoc = glGetUniformLocation(prog, "kinds");
	directionsLoc = glGetUniformLocation(prog, "directions");
	lightColorsLoc = glGetUniformLocation(prog, "lightColors");
	if (countLoc < 0 || kindsLoc < 0 || directionsLoc < 0 ||
	    lightColorsLoc < 0) {
	    fprintf(stderr,
		    "  FAIL: lighting-array base locations unavailable\n");
	    glDeleteProgram(prog);
	    g_failed++;
	    return;
	}

	glUseProgram(prog);
	glUniform1i(countLoc, 1);
	glUniform1iv(kindsLoc, 2, kinds);
	glUniform3fv(directionsLoc, 2, directions);
	glUniform3fv(lightColorsLoc, 2, lightColors);
	glClear(GL_COLOR_BUFFER_BIT);
	glBegin(GL_QUADS);
	glVertex2f(-1.0f, -1.0f);
	glVertex2f( 1.0f, -1.0f);
	glVertex2f( 1.0f,  1.0f);
	glVertex2f(-1.0f,  1.0f);
	glEnd();
	glFinish();
	glUseProgram(0);
	glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
	glDeleteProgram(prog);

	if (check_gl_error("glsl_uniform_array_lighting")) {
	    fprintf(stderr, "  FAIL: GL error during lighting-array test\n");
	    g_failed++;
	} else if (px[0] > 240 && px[1] > 240 && px[2] > 240) {
	    printf("  PASS: looped lighting arrays produced white\n");
	} else {
	    fprintf(stderr,
		    "  FAIL: lighting-array output (%d,%d,%d), expected white\n",
		    px[0], px[1], px[2]);
	    g_failed++;
	}
    }
}

/* ------------------------------------------------------------------ */
/* Test 18ab: GLSL uniform matrix-vector multiplication                */
/* ------------------------------------------------------------------ */
static void
test_glsl_uniform_matrix_vector(int W, int H)
{
    const char *vert =
	"#version 110\n"
	"uniform mat4 matrix;\n"
	"uniform vec4 operand;\n"
	"varying vec4 result;\n"
	"void main() {\n"
	"  gl_Position = gl_Vertex;\n"
	"  result = matrix * operand;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"varying vec4 result;\n"
	"void main() { gl_FragColor = result; }\n";
    const GLfloat matrix[16] = {
	1.0f, 0.0f, 4.0f, 0.0f,
	2.0f, 1.0f, 0.0f, 0.0f,
	0.0f, 3.0f, 1.0f, 0.0f,
	0.0f, 0.0f, 0.0f, 1.0f
    };
    const GLfloat operand[4] = {0.1f, 0.2f, 0.1f, 1.0f};
    GLubyte px[4] = {0};
    GLuint prog;
    GLint matrixLoc;
    GLint operandLoc;

    printf("Test 18ab: GLSL uniform matrix-vector multiplication\n");
    prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: matrix-vector program compilation/link failed\n");
	g_failed++;
	return;
    }

    matrixLoc = glGetUniformLocation(prog, "matrix");
    operandLoc = glGetUniformLocation(prog, "operand");
    if (matrixLoc < 0 || operandLoc < 0) {
	fprintf(stderr, "  FAIL: matrix-vector uniforms unavailable\n");
	glDeleteProgram(prog);
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glUniformMatrix4fv(matrixLoc, 1, GL_FALSE, matrix);
    glUniform4fv(operandLoc, 1, operand);
    glViewport(0, 0, W, H);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();
    glUseProgram(0);
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_uniform_matrix_vector")) {
	fprintf(stderr, "  FAIL: GL error during matrix-vector test\n");
	g_failed++;
    } else if (px[0] > 120 && px[0] < 136 &&
	       px[1] > 120 && px[1] < 136 &&
	       px[2] > 120 && px[2] < 136 && px[3] > 250) {
	printf("  PASS: uniform matrix-vector output (%d,%d,%d,%d)\n",
	       px[0], px[1], px[2], px[3]);
    } else {
	fprintf(stderr,
		"  FAIL: matrix-vector output (%d,%d,%d,%d), expected gray\n",
		px[0], px[1], px[2], px[3]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18ac: GLSL uniform shared between vertex and fragment stages   */
/* ------------------------------------------------------------------ */
static void
test_glsl_shared_uniform_stages(int W, int H)
{
    const char *vert =
	"attribute vec3 position;\n"
	"attribute vec3 normal;\n"
	"uniform mat4 model;\n"
	"uniform mat4 viewProj;\n"
	"uniform vec4 tint;\n"
	"uniform int hasNormal;\n"
	"uniform int popLevel;\n"
	"varying vec3 result;\n"
	"void main() {\n"
	"  gl_Position = viewProj * model * vec4(position, 1.0);\n"
	"  result = (hasNormal != 0) ? normal : vec3(0.0, 0.0, 1.0);\n"
	"  if (popLevel < -100) result = vec3(1.0, 0.0, 0.0);\n"
	"}\n";
    const char *frag =
	"uniform vec4 tint;\n"
	"uniform int hasNormal;\n"
	"varying vec3 result;\n"
	"void main() {\n"
	"  if (hasNormal == 0)\n"
	"    gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);\n"
	"  else\n"
	"    gl_FragColor = vec4((result * 0.5 + vec3(0.5)) * tint.rgb,\n"
	"                        tint.a);\n"
	"}\n";
    static const GLfloat positions[] = {
	-1.0f, -1.0f, 0.0f,
	 1.0f, -1.0f, 0.0f,
	 0.0f,  1.0f, 0.0f
    };
    static const GLfloat normals[] = {
	0.0f, 1.0f, 0.0f,
	0.0f, 1.0f, 0.0f,
	0.0f, 1.0f, 0.0f
    };
    static const GLubyte indices[] = {0, 1, 2};
    static const GLfloat identity[] = {
	1, 0, 0, 0,  0, 1, 0, 0,
	0, 0, 1, 0,  0, 0, 0, 1
    };
    static const GLfloat white[] = {1, 1, 1, 1};
    GLubyte px[4] = {0};
    GLint stored = 0;
    GLuint prog;
    GLint positionLoc;
    GLint normalLoc;
    GLint uniformLoc;
    GLint popLevelLoc;

    printf("Test 18ac: GLSL cross-stage shared uniform\n");
    prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: cross-stage uniform program failed\n");
	g_failed++;
	return;
    }
    glBindAttribLocation(prog, 0, "position");
    glBindAttribLocation(prog, 1, "normal");
    glLinkProgram(prog);
    positionLoc = glGetAttribLocation(prog, "position");
    normalLoc = glGetAttribLocation(prog, "normal");
    uniformLoc = glGetUniformLocation(prog, "hasNormal");
    popLevelLoc = glGetUniformLocation(prog, "popLevel");
    if (positionLoc != 0 || normalLoc != 1 ||
	uniformLoc < 0 || popLevelLoc < 0) {
	fprintf(stderr,
		"  FAIL: cross-stage locations pos=%d norm=%d uniform=%d "
		"pop=%d\n",
		positionLoc, normalLoc, uniformLoc, popLevelLoc);
	glDeleteProgram(prog);
	g_failed++;
	return;
    }

    glUseProgramObjectARB(prog);
    glUniformMatrix4fv(glGetUniformLocation(prog, "model"), 1, GL_FALSE,
		       identity);
    glUniformMatrix4fv(glGetUniformLocation(prog, "viewProj"), 1, GL_FALSE,
		       identity);
    glUniform4fv(glGetUniformLocation(prog, "tint"), 1, white);
    glUniform1iARB(uniformLoc, 1);
    glUniform1iARB(popLevelLoc, -1);
    glGetUniformiv(prog, uniformLoc, &stored);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray((GLuint) positionLoc);
    glEnableVertexAttribArray((GLuint) normalLoc);
    glVertexAttribPointer((GLuint) positionLoc, 3, GL_FLOAT, GL_FALSE, 0,
			  positions);
    glVertexAttribPointer((GLuint) normalLoc, 3, GL_FLOAT, GL_FALSE, 0,
			  normals);
    glViewport(0, 0, W, H);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_BYTE, indices);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glDisableVertexAttribArray((GLuint) normalLoc);
    glDisableVertexAttribArray((GLuint) positionLoc);
    glUseProgram(0);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_shared_uniform_stages")) {
	fprintf(stderr, "  FAIL: GL error during cross-stage uniform test\n");
	g_failed++;
    } else if (stored == 1 &&
	       px[0] > 115 && px[0] < 140 &&
	       px[1] > 240 &&
	       px[2] > 115 && px[2] < 140) {
	printf("  PASS: shared uniform reached both stages (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: shared uniform stored=%d output=(%d,%d,%d), "
		"expected green-normal encoding\n",
		stored, px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18a: GLSL 1.20 uniform structures                             */
/* ------------------------------------------------------------------ */
static void
test_glsl_uniform_struct(int W, int H)
{
    static const char struct_decls[] =
	"struct Nested { vec4 color; };\n"
	"struct Params {\n"
	"    mat4 vertexTransform;\n"
	"    mat3 textureTransform;\n"
	"    float opacity;\n"
	"    int swizzle;\n"
	"    Nested nested;\n"
	"};\n"
	"uniform Params params;\n";
    char vert[1024];
    char frag[1024];
    const GLfloat mat4_identity[16] = {
	1, 0, 0, 0,
	0, 1, 0, 0,
	0, 0, 1, 0,
	0, 0, 0, 1
    };
    const GLfloat mat3_identity[9] = {
	1, 0, 0,
	0, 1, 0,
	0, 0, 1
    };
    const GLfloat color[4] = { 0.1f, 0.8f, 0.2f, 1.0f };
    const char *names[] = {
	"params.vertexTransform",
	"params.textureTransform",
	"params.opacity",
	"params.swizzle",
	"params.nested.color"
    };
    GLint locations[5];
    GLubyte px[4] = { 0 };
    GLuint prog;
    GLuint i;

    printf("Test 18a: GLSL 1.20 uniform structures\n");
    clear_errors();

    snprintf(vert, sizeof(vert),
	"#version 120\n%s"
	"void main() {\n"
	"    gl_Position = params.vertexTransform * gl_Vertex;\n"
	"}\n", struct_decls);
    snprintf(frag, sizeof(frag),
	"#version 120\n%s"
	"void main() {\n"
	"    if (params.swizzle == 0)\n"
	"        gl_FragColor = vec4(params.nested.color.rgb * params.opacity, 1.0);\n"
	"    else\n"
	"        gl_FragColor = params.nested.color.bgra;\n"
	"}\n", struct_decls);

    prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: uniform-structure program compilation/link failed\n");
	g_failed++;
	return;
    }

    for (i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
	locations[i] = glGetUniformLocation(prog, names[i]);
	if (locations[i] < 0) {
	    fprintf(stderr, "  FAIL: no location for %s\n", names[i]);
	    g_failed++;
	    glDeleteProgram(prog);
	    return;
	}
    }

    glUseProgram(prog);
    glUniformMatrix4fv(locations[0], 1, GL_FALSE, mat4_identity);
    glUniformMatrix3fv(locations[1], 1, GL_FALSE, mat3_identity);
    glUniform1f(locations[2], 1.0f);
    glUniform1i(locations[3], 0);
    glUniform4fv(locations[4], 1, color);

    glViewport(0, 0, W, H);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glUseProgram(0);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_uniform_struct")) {
	fprintf(stderr, "  FAIL: GL error during uniform-structure test\n");
	g_failed++;
	return;
    }
    if (px[0] < 15 || px[0] > 40 ||
	px[1] < 180 || px[1] > 225 ||
	px[2] < 35 || px[2] > 70) {
	fprintf(stderr,
		"  FAIL: uniform-structure output (%d,%d,%d) expected ~(26,204,51)\n",
		px[0], px[1], px[2]);
	g_failed++;
    } else {
	printf("  PASS: uniform-structure output (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    }
}

/* Exercise the same GLSL 1.20 shape used by Qt's backing-store compositor:
 * separate structure instances per stage, two generic attributes, a transformed
 * texture coordinate, and a sampler bound to texture unit one.
 */
static void
test_glsl_uniform_struct_texture(int W, int H)
{
    static const char *vert =
	"#version 120\n"
	"struct Params { mat4 vertexTransform; mat3 textureTransform; float opacity; int swizzle; };\n"
	"uniform Params vertexParams;\n"
	"attribute vec3 position;\n"
	"attribute vec2 texcoord;\n"
	"varying vec2 v_texcoord;\n"
	"void main() {\n"
	"    v_texcoord = (vertexParams.textureTransform * vec3(texcoord, 1.0)).xy;\n"
	"    gl_Position = vertexParams.vertexTransform * vec4(position, 1.0);\n"
	"}\n";
    static const char *frag =
	"#version 120\n"
	"struct Params { mat4 vertexTransform; mat3 textureTransform; float opacity; int swizzle; };\n"
	"uniform Params fragmentParams;\n"
	"uniform sampler2D textureSampler;\n"
	"varying vec2 v_texcoord;\n"
	"void main() {\n"
	"    vec4 c = texture2D(textureSampler, v_texcoord);\n"
	"    c.a *= fragmentParams.opacity;\n"
	"    if (fragmentParams.swizzle == 0) gl_FragData[0] = c;\n"
	"    else gl_FragData[0] = c.bgra;\n"
	"}\n";
    static const GLfloat vertex_data[] = {
	-1, -1, 0,  0, 0,
	-1,  1, 0,  0, 1,
	 1, -1, 0,  1, 0,
	-1,  1, 0,  0, 1,
	 1, -1, 0,  1, 0,
	 1,  1, 0,  1, 1
    };
    static const GLubyte texel[] = { 26, 204, 51, 255 };
    static const GLfloat mat4_identity[] = {
	1, 0, 0, 0,  0, 1, 0, 0,  0, 0, 1, 0,  0, 0, 0, 1
    };
    static const GLfloat mat3_identity[] = {
	1, 0, 0,  0, 1, 0,  0, 0, 1
    };
    GLint vertex_transform;
    GLint texture_transform;
    GLint opacity;
    GLint swizzle;
    GLint sampler;
    GLint position_attr;
    GLint texcoord_attr;
    GLuint texture = 0;
    GLuint vbo = 0;
    GLuint prog;
    GLubyte px[4] = { 0 };

    printf("Test 18aa: GLSL uniform-structure texture compositor\n");
    clear_errors();
    prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: compositor-style program compilation/link failed\n");
	g_failed++;
	return;
    }

    glBindAttribLocation(prog, 0, "position");
    glBindAttribLocation(prog, 1, "texcoord");

    vertex_transform = glGetUniformLocation(prog, "vertexParams.vertexTransform");
    texture_transform = glGetUniformLocation(prog, "vertexParams.textureTransform");
    opacity = glGetUniformLocation(prog, "fragmentParams.opacity");
    swizzle = glGetUniformLocation(prog, "fragmentParams.swizzle");
    sampler = glGetUniformLocation(prog, "textureSampler");
    position_attr = glGetAttribLocation(prog, "position");
    texcoord_attr = glGetAttribLocation(prog, "texcoord");
    if (vertex_transform < 0 || texture_transform < 0 || opacity < 0 ||
	swizzle < 0 || sampler < 0 || position_attr < 0 || texcoord_attr < 0) {
	fprintf(stderr, "  FAIL: compositor-style shader locations unavailable\n");
	g_failed++;
	glDeleteProgram(prog);
	return;
    }

    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA,
		 GL_UNSIGNED_BYTE, texel);

    glUseProgram(prog);
    glUniformMatrix4fv(vertex_transform, 1, GL_FALSE, mat4_identity);
    glUniformMatrix3fv(texture_transform, 1, GL_FALSE, mat3_identity);
    glUniform1f(opacity, 1.0f);
    glUniform1i(swizzle, 0);
    glUniform1i(sampler, 1);
    glViewport(0, 0, W, H);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertex_data), vertex_data,
		 GL_STATIC_DRAW);
    glEnableVertexAttribArray(position_attr);
    glEnableVertexAttribArray(texcoord_attr);
    glVertexAttribPointer(position_attr, 3, GL_FLOAT, GL_FALSE,
			 5 * sizeof(GLfloat), (const GLvoid *) 0);
    glVertexAttribPointer(texcoord_attr, 2, GL_FLOAT, GL_FALSE,
			 5 * sizeof(GLfloat),
			 (const GLvoid *) (3 * sizeof(GLfloat)));
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glDisableVertexAttribArray(position_attr);
    glDisableVertexAttribArray(texcoord_attr);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glDeleteBuffers(1, &vbo);
    glUseProgram(0);
    glDeleteTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_uniform_struct_texture") ||
	px[0] < 15 || px[0] > 40 || px[1] < 180 || px[1] > 225 ||
	px[2] < 35 || px[2] > 70) {
	fprintf(stderr,
		"  FAIL: compositor-style output (%d,%d,%d), expected ~(26,204,51)\n",
		px[0], px[1], px[2]);
	g_failed++;
    } else {
	printf("  PASS: compositor-style output (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    }
}

/* ------------------------------------------------------------------ */
/* Test 18b: glDrawElements with GLSL program (generic attrib 0)       */
/* ------------------------------------------------------------------ */
static void
test_glsl_drawelements(int W, int H)
{
    printf("Test 18b: glDrawElements + GLSL (generic vertex attribute)\n");

    if (!check_ext("GL_ARB_shader_objects") ||
	!check_ext("GL_ARB_vertex_shader"))
	return;

    clear_errors();

    /* Vertex shader reads gl_Vertex (attribute 0); fragment shader
     * passes gl_Color through.  Vertex data is supplied via
     * glVertexAttribPointer(0,...) so Vertex.Enabled is FALSE — the
     * path that was incorrectly rejected by _mesa_validate_DrawElements. */
    const char *vert =
	"#version 110\n"
	"void main() {\n"
	"    gl_Position = gl_Vertex;\n"
	"    gl_FrontColor = gl_Color;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"void main() {\n"
	"    gl_FragColor = gl_Color;\n"
	"}\n";

    GLuint prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: GLSL program compilation/link failed\n");
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor4f(0.0f, 0.0f, 1.0f, 1.0f);   /* blue via current vertex color */

    /* Full-screen quad via generic attribute 0 + indexed draw */
    static const GLfloat verts[] = {
	-1.0f, -1.0f,
	 1.0f, -1.0f,
	 1.0f,  1.0f,
	-1.0f,  1.0f,
    };
    static const GLubyte idx[] = { 0, 1, 2,  0, 2, 3 };

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, verts);
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_BYTE, idx);
    glFinish();
    glDisableVertexAttribArray(0);

    glUseProgram(0);
    glDeleteProgram(prog);

    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("glsl_drawelements")) {
	fprintf(stderr, "  FAIL: GL error during GLSL DrawElements test\n");
	g_failed++;
	return;
    }

    if (px[0] < 50 && px[1] < 50 && px[2] > 200) {
	printf("  PASS: glDrawElements+GLSL output blue (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: glDrawElements+GLSL output (%d,%d,%d) expected ~(0,0,255)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18c: GLSL varying interpolation over GL_LINES                  */
/* ------------------------------------------------------------------ */
static void
test_glsl_line_varying(int W, int H)
{
    printf("Test 18c: GLSL varying interpolation over GL_LINES\n");

    if (!check_ext("GL_ARB_shader_objects") ||
	!check_ext("GL_ARB_vertex_shader") ||
	!check_ext("GL_ARB_fragment_shader"))
	return;

    clear_errors();

    /*
     * Vertex shader: pass position through and forward gl_Color as a varying.
     * Fragment shader: output the interpolated varying as the fragment color.
     *
     * We draw a horizontal line across the full viewport width between two
     * vertices that have different clip-space W values (achieved by setting
     * gl_Position.w explicitly) so that perspective-correct interpolation
     * is exercised.
     *
     * Vertex 0: gl_Position = (-1, 0, 0, 1)   color = (0, 0, 1, 1)  blue
     * Vertex 1: gl_Position = ( 2, 0, 0, 2)   → NDC x = 1   color = (0, 1, 0, 1)  green
     *
     * After perspective division:
     *   vert0: x_win ~ 0,    W_clip = 1,   win[3] = 1/W_clip = 1.0
     *   vert1: x_win ~ W-1,  W_clip = 2,   win[3] = 1/W_clip = 0.5
     *
     * Perspective-correct color at the screen midpoint (x_screen = W/2):
     *   t_screen = 0.5
     *   t_correct = (t_screen * invw1) / ((1-t_screen)*invw0 + t_screen*invw1)
     *             = (0.5 * 0.5) / (0.5*1.0 + 0.5*0.5)
     *             = 0.25 / 0.75 = 1/3  ≈ 0.333
     *   blue  component = (1 - 1/3) = 2/3 ≈ 170
     *   green component = 1/3         ≈  85
     *
     * If the bug is present (WPOS.w hardcoded to 1.0), interpolation is linear:
     *   t = 0.5 → blue = 128, green = 128.
     *
     * We therefore check that blue > green at the midpoint, which is only
     * true for perspective-correct interpolation.
     */
    const char *vert =
	"#version 110\n"
	"varying vec4 vColor;\n"
	"void main() {\n"
	"    gl_Position = gl_Vertex;\n"
	"    vColor = gl_Color;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"varying vec4 vColor;\n"
	"void main() {\n"
	"    gl_FragColor = vColor;\n"
	"}\n";

    GLuint prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: GLSL line-varying program compilation/link failed\n");
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_DEPTH_TEST);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    /*
     * Vertex 0: clip pos (-1, 0, 0, 1) → NDC (-1, 0, 0) → left edge;  blue
     * Vertex 1: clip pos ( 2, 0, 0, 2) → NDC ( 1, 0, 0) → right edge; green
     */
    glBegin(GL_LINES);
    glColor4f(0.0f, 0.0f, 1.0f, 1.0f);  /* blue  at vert 0 */
    glVertex4f(-1.0f, 0.0f, 0.0f, 1.0f);
    glColor4f(0.0f, 1.0f, 0.0f, 1.0f);  /* green at vert 1 */
    glVertex4f( 2.0f, 0.0f, 0.0f, 2.0f);
    glEnd();
    glFinish();

    glUseProgram(0);
    glDeleteProgram(prog);

    /* Sample the midpoint of the line */
    GLubyte px[4] = {0};
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    if (check_gl_error("glsl_line_varying")) {
	fprintf(stderr, "  FAIL: GL error during GLSL line-varying test\n");
	g_failed++;
	return;
    }

    /* The line should have rendered some color at the midpoint */
    if (px[0] == 0 && px[1] == 0 && px[2] == 0) {
	fprintf(stderr, "  FAIL: no line pixels rendered at midpoint\n");
	g_failed++;
	return;
    }

    /*
     * Perspective-correct: blue > green (blue ≈ 170, green ≈ 85).
     * Linear (bug):        blue == green == 128.
     */
    if (px[2] > px[1]) {
	printf("  PASS: GLSL line varying perspective-correct "
	       "(blue=%d > green=%d at midpoint)\n", px[2], px[1]);
    } else {
	fprintf(stderr,
		"  FAIL: GLSL line varying NOT perspective-correct "
		"(blue=%d, green=%d; expected blue > green)\n",
		px[2], px[1]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18d: dFdx/dFdy of a perspective-correct varying               */
/* ------------------------------------------------------------------ */
static void
test_glsl_perspective_derivatives(int W, int H)
{
    const char *vert =
	"#version 110\n"
	"varying vec3 vPosition;\n"
	"void main() {\n"
	"  vPosition = gl_Vertex.xyz;\n"
	"  gl_Position = vec4(gl_Vertex.xy, 0.0, gl_Vertex.z);\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"varying vec3 vPosition;\n"
	"void main() {\n"
	"  vec3 n = normalize(cross(dFdx(vPosition), dFdy(vPosition)));\n"
	"  gl_FragColor = vec4(n * 0.5 + vec3(0.5), 1.0);\n"
	"}\n";
    GLubyte px[4] = {0};
    GLuint prog;

    printf("Test 18d: GLSL perspective-varying derivatives\n");
    prog = make_program(vert, frag);
    if (!prog) {
	fprintf(stderr, "  FAIL: derivative program compilation/link failed\n");
	g_failed++;
	return;
    }

    glUseProgram(prog);
    glViewport(0, 0, W, H);
    glDisable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_TRIANGLES);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f( 2.0f, -2.0f, 2.0f);
    glVertex3f( 0.0f,  3.0f, 3.0f);
    glEnd();
    glFinish();
    glUseProgram(0);
    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glDeleteProgram(prog);

    /* The world-space triangle normal is normalize((-6,-5,13)).
     * Mapping it from [-1,1] to [0,255] gives approximately (77,85,237). */
    if (check_gl_error("glsl_perspective_derivatives")) {
	fprintf(stderr, "  FAIL: GL error during derivative test\n");
	g_failed++;
    } else if (px[0] > 65 && px[0] < 90 &&
	       px[1] > 70 && px[1] < 100 &&
	       px[2] > 225 && px[2] < 250) {
	printf("  PASS: perspective derivatives produced normal (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: derivative normal (%d,%d,%d), expected ~(77,85,237)\n",
		px[0], px[1], px[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18e: Obol CAD shaded GLSL contract                             */
/* ------------------------------------------------------------------ */
static int
relink_obol_cad_program(GLuint program, int has_normal)
{
    GLint linked = GL_FALSE;
    char log[512] = {0};

    glBindAttribLocation(program, 0, "a_pos");
    if (has_normal)
	glBindAttribLocation(program, 1, "a_norm");
    glLinkProgram(program);
    glGetProgramiv(program, GL_LINK_STATUS, &linked);
    if (linked)
	return 1;
    glGetProgramInfoLog(program, sizeof(log), NULL, log);
    fprintf(stderr, "  Obol attribute-binding relink failed: %s\n", log);
    return 0;
}

static void
test_glsl_obol_cad_shading(int W, int H)
{
    const char *faceVert =
	"attribute vec3 a_pos;\n"
	"void main() { gl_Position = vec4(a_pos, 1.0); }\n";
    const char *faceFrag =
	"void main() {\n"
	"  if (gl_FrontFacing)\n"
	"    gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n"
	"  else\n"
	"    gl_FragColor = vec4(0.0, 0.0, 1.0, 1.0);\n"
	"}\n";
    const char *vert =
	"attribute vec3 a_pos;\n"
	"attribute vec3 a_norm;\n"
	"uniform mat4  u_model;\n"
	"uniform mat4  u_viewProj;\n"
	"uniform vec4  u_color;\n"
	"uniform int   u_hasNorm;\n"
	"uniform int   u_popLevel;\n"
	"uniform float u_popMask;\n"
	"uniform vec3  u_popMin;\n"
	"uniform vec3  u_popMax;\n"
	"varying vec3  v_norm;\n"
	"varying vec3  v_worldPos;\n"
	"varying vec4  v_color;\n"
	"vec3 popPosition(vec3 p) {\n"
	"  if (u_popLevel < 0 || u_popLevel >= 15) return p;\n"
	"  vec3 extent = u_popMax - u_popMin;\n"
	"  vec3 safeExtent = max(extent, vec3(1.0e-30));\n"
	"  vec3 scaled = (p - u_popMin) / safeExtent * 65535.0;\n"
	"  vec3 low = floor(floor(scaled) / u_popMask);\n"
	"  vec3 high = ceil(ceil(scaled) / u_popMask);\n"
	"  return ((low + high) * (0.5 * u_popMask / 65535.0)) *\n"
	"         extent + u_popMin;\n"
	"}\n"
	"void main() {\n"
	"  vec4 wp = u_model * vec4(popPosition(a_pos), 1.0);\n"
	"  gl_Position = u_viewProj * wp;\n"
	"  v_worldPos = wp.xyz;\n"
	"  if (u_hasNorm != 0) {\n"
	"    v_norm = mat3(u_model[0].xyz, u_model[1].xyz,\n"
	"                  u_model[2].xyz) * a_norm;\n"
	"  } else {\n"
	"    v_norm = vec3(0.0, 0.0, 1.0);\n"
	"  }\n"
	"  v_color = u_color;\n"
	"}\n";
    const char *frag =
	"uniform int   u_numLights;\n"
	"uniform int   u_hasNorm;\n"
	"uniform int   u_ltype[8];\n"
	"uniform vec3  u_lvec[8];\n"
	"uniform vec3  u_laxis[8];\n"
	"uniform vec3  u_lcolor[8];\n"
	"uniform float u_lcos[8];\n"
	"varying vec3  v_norm;\n"
	"varying vec3  v_worldPos;\n"
	"varying vec4  v_color;\n"
	"void main() {\n"
	"  vec3 n;\n"
	"  if (u_hasNorm != 0) {\n"
	"    n = normalize(v_norm);\n"
	"    if (!gl_FrontFacing) n = -n;\n"
	"  } else {\n"
	"    vec3 fn = cross(dFdx(v_worldPos), dFdy(v_worldPos));\n"
	"    float fl = length(fn);\n"
	"    n = (fl > 0.0) ? fn / fl : vec3(0.0, 0.0, 1.0);\n"
	"  }\n"
	"  vec3 col = v_color.rgb * 0.25;\n"
	"  for (int i = 0; i < 8; i++) {\n"
	"    if (i >= u_numLights) break;\n"
	"    vec3 L;\n"
	"    float atten = 1.0;\n"
	"    if (u_ltype[i] == 0) {\n"
	"      L = normalize(u_lvec[i]);\n"
	"    } else {\n"
	"      vec3 d = u_lvec[i] - v_worldPos;\n"
	"      float dl = length(d);\n"
	"      L = (dl > 0.0) ? d / dl : vec3(0.0, 0.0, 1.0);\n"
	"      if (u_ltype[i] == 2) {\n"
	"        float c = dot(normalize(u_laxis[i]), -L);\n"
	"        if (c < u_lcos[i]) atten = 0.0;\n"
	"      }\n"
	"    }\n"
	"    float ndl = max(0.0, dot(n, L));\n"
	"    col += v_color.rgb * u_lcolor[i] * (ndl * 0.75 * atten);\n"
	"  }\n"
	"  gl_FragColor = vec4(col, v_color.a);\n"
	"}\n";
    const char *normalDebugFrag =
	"uniform int u_hasNorm;\n"
	"varying vec3 v_norm;\n"
	"void main() {\n"
	"  vec3 n = normalize(v_norm);\n"
	"  if (!gl_FrontFacing) n = -n;\n"
	"  gl_FragColor = (u_hasNorm == 0) ?\n"
	"    vec4(1.0, 1.0, 0.0, 1.0) :\n"
	"    vec4(n * 0.5 + vec3(0.5), 1.0);\n"
	"}\n";
    static const GLfloat positions[] = {
	-1.0f, -1.0f, 0.0f,
	 1.0f, -1.0f, 0.0f,
	 0.0f,  1.0f, 0.0f
    };
    static const GLfloat normals[] = {
	0.0f, 1.0f, 0.0f,
	0.0f, 1.0f, 0.0f,
	0.0f, 1.0f, 0.0f
    };
    static const GLfloat rotationNormals[] = {
	0.0f, 0.0f, 1.0f,
	0.0f, 0.0f, 1.0f,
	0.0f, 0.0f, 1.0f
    };
    static const GLubyte indices[] = {0, 1, 2};
    static const GLubyte reverseIndices[] = {0, 2, 1};
    static const GLuint vboIndices[] = {0, 1, 2};
    static const GLfloat identity[] = {
	1, 0, 0, 0,  0, 1, 0, 0,
	0, 0, 1, 0,  0, 0, 0, 1
    };
    static const GLfloat rotateY90[] = {
	0, 0, -1, 0,  0, 1, 0, 0,
	1, 0,  0, 0,  0, 0, 0, 1
    };
    static const GLfloat rotateYMinus90[] = {
	 0, 0, 1, 0,  0, 1, 0, 0,
	-1, 0, 0, 0,  0, 0, 0, 1
    };
    static const GLfloat white[] = {1, 1, 1, 1};
    static const GLfloat lightVector[] = {0, 1, 0};
    static const GLfloat backLightVector[] = {0,-1, 0};
    static const GLfloat rotatedLightVector[] = {1, 0, 0};
    static const GLfloat lightAxis[] = {0, 0, -1};
    static const GLfloat lightColor[] = {1, 1, 1};
    static const GLfloat popMinimum[] = {-1, -1, -1};
    static const GLfloat popMaximum[] = {1, 1, 1};
    const GLint lightType = 0;
    const GLfloat lightCos = -2.0f;
    GLubyte px[4] = {0};
    GLubyte backPx[4] = {0};
    GLubyte normalDebugPx[4] = {0};
    GLubyte rotatedPx[4] = {0};
    GLubyte backLitPx[4] = {0};
    GLuint prog;
    GLuint positionBuffer = 0;
    GLuint normalBuffer = 0;
    GLuint indexBuffer = 0;
    GLint posLoc;
    GLint normLoc;

    printf("Test 18e: Obol CAD shaded GLSL contract\n");
    clear_errors();
    glViewport(0, 0, W, H);
    glDisable(GL_CULL_FACE);
    glDisable(GL_DEPTH_TEST);
    glFrontFace(GL_CCW);

    prog = make_program(faceVert, faceFrag);
    if (!prog || !relink_obol_cad_program(prog, 0)) {
	fprintf(stderr, "  FAIL: gl_FrontFacing program failed\n");
	if (prog)
	    glDeleteProgram(prog);
	g_failed++;
	return;
    }
    posLoc = glGetAttribLocation(prog, "a_pos");
    glUseProgram(prog);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray((GLuint) posLoc);
    glVertexAttribPointer((GLuint) posLoc, 3, GL_FLOAT, GL_FALSE, 0,
			  positions);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_BYTE, indices);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_BYTE, reverseIndices);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, backPx);
    glDisableVertexAttribArray((GLuint) posLoc);
    glUseProgram(0);
    glDeleteProgram(prog);
    if (px[0] < 240 || px[1] > 15 || px[2] > 15) {
	fprintf(stderr,
		"  FAIL: front-facing triangle reported (%d,%d,%d), expected red\n",
		px[0], px[1], px[2]);
	g_failed++;
    } else {
	printf("  PASS: gl_FrontFacing identified the front face\n");
    }
    if (backPx[0] > 15 || backPx[1] > 15 || backPx[2] < 240) {
	fprintf(stderr,
		"  FAIL: back-facing triangle reported (%d,%d,%d), expected blue\n",
		backPx[0], backPx[1], backPx[2]);
	g_failed++;
    } else {
	printf("  PASS: gl_FrontFacing identified the back face\n");
    }

    /*
     * Obol's integrated normal diagnostic uses a conditional expression
     * after normalizing and possibly flipping the varying.  Keep this exact
     * shape here: it previously selected the zero-uniform arm even though
     * glGetUniformiv and the fragment interpreter both observed one.
     */
    prog = make_program(vert, normalDebugFrag);
    if (!prog || !relink_obol_cad_program(prog, 1)) {
	fprintf(stderr, "  FAIL: Obol normal-debug program failed\n");
	if (prog)
	    glDeleteProgram(prog);
	g_failed++;
	return;
    }
    posLoc = glGetAttribLocation(prog, "a_pos");
    normLoc = glGetAttribLocation(prog, "a_norm");
    glUseProgram(prog);
    glUniformMatrix4fv(glGetUniformLocation(prog, "u_model"), 1, GL_FALSE,
		       identity);
    glUniformMatrix4fv(glGetUniformLocation(prog, "u_viewProj"), 1, GL_FALSE,
		       identity);
    glUniform1i(glGetUniformLocation(prog, "u_hasNorm"), 1);
    glUniform1i(glGetUniformLocation(prog, "u_popLevel"), 15);
    glUniform1f(glGetUniformLocation(prog, "u_popMask"), 1.0f);
    glUniform3fv(glGetUniformLocation(prog, "u_popMin"), 1, popMinimum);
    glUniform3fv(glGetUniformLocation(prog, "u_popMax"), 1, popMaximum);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray((GLuint) posLoc);
    glEnableVertexAttribArray((GLuint) normLoc);
    glVertexAttribPointer((GLuint) posLoc, 3, GL_FLOAT, GL_FALSE, 0,
			  positions);
    glVertexAttribPointer((GLuint) normLoc, 3, GL_FLOAT, GL_FALSE, 0,
			  normals);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_BYTE, indices);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE,
		 normalDebugPx);
    glDisableVertexAttribArray((GLuint) normLoc);
    glDisableVertexAttribArray((GLuint) posLoc);
    glUseProgram(0);
    glDeleteProgram(prog);
    if (normalDebugPx[0] > 115 && normalDebugPx[0] < 140 &&
	normalDebugPx[1] > 240 &&
	normalDebugPx[2] > 115 && normalDebugPx[2] < 140) {
	printf("  PASS: Obol normal-debug conditional selected normal "
	       "(%d,%d,%d)\n", normalDebugPx[0], normalDebugPx[1],
	       normalDebugPx[2]);
    } else {
	fprintf(stderr,
		"  FAIL: Obol normal-debug conditional produced (%d,%d,%d), "
		"expected green-normal encoding\n",
		normalDebugPx[0], normalDebugPx[1], normalDebugPx[2]);
	g_failed++;
    }

    prog = make_program(vert, frag);
    if (!prog || !relink_obol_cad_program(prog, 1)) {
	fprintf(stderr, "  FAIL: Obol shaded program failed\n");
	if (prog)
	    glDeleteProgram(prog);
	g_failed++;
	return;
    }
    posLoc = glGetAttribLocation(prog, "a_pos");
    normLoc = glGetAttribLocation(prog, "a_norm");
    if (posLoc < 0 || normLoc < 0) {
	fprintf(stderr, "  FAIL: Obol position/normal attributes unavailable\n");
	glDeleteProgram(prog);
	g_failed++;
	return;
    }
    glUseProgram(prog);
#define SET_MAT4(_name, _value) \
    glUniformMatrix4fv(glGetUniformLocation(prog, (_name)), 1, GL_FALSE, (_value))
#define SET_INT(_name, _value) \
    glUniform1i(glGetUniformLocation(prog, (_name)), (_value))
    SET_MAT4("u_model", identity);
    SET_MAT4("u_viewProj", identity);
    glUniform4fv(glGetUniformLocation(prog, "u_color"), 1, white);
    SET_INT("u_hasNorm", 1);
    SET_INT("u_popLevel", 15);
    glUniform1f(glGetUniformLocation(prog, "u_popMask"), 1.0f);
    glUniform3fv(glGetUniformLocation(prog, "u_popMin"), 1, popMinimum);
    glUniform3fv(glGetUniformLocation(prog, "u_popMax"), 1, popMaximum);
    SET_INT("u_numLights", 1);
    glUniform1iv(glGetUniformLocation(prog, "u_ltype"), 1, &lightType);
    glUniform3fv(glGetUniformLocation(prog, "u_lvec"), 1, lightVector);
    glUniform3fv(glGetUniformLocation(prog, "u_laxis"), 1, lightAxis);
    glUniform3fv(glGetUniformLocation(prog, "u_lcolor"), 1, lightColor);
    glUniform1fv(glGetUniformLocation(prog, "u_lcos"), 1, &lightCos);
#undef SET_INT
#undef SET_MAT4

    glGenBuffers(1, &positionBuffer);
    glGenBuffers(1, &normalBuffer);
    glGenBuffers(1, &indexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, positionBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(positions), positions, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, normalBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(normals), normals, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(vboIndices), vboIndices,
		 GL_STATIC_DRAW);
    glEnableVertexAttribArray((GLuint) posLoc);
    glEnableVertexAttribArray((GLuint) normLoc);
    glBindBuffer(GL_ARRAY_BUFFER, positionBuffer);
    glVertexAttribPointer((GLuint) posLoc, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glBindBuffer(GL_ARRAY_BUFFER, normalBuffer);
    glVertexAttribPointer((GLuint) normLoc, 3, GL_FLOAT, GL_FALSE, 0, NULL);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, NULL);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);

    glUniform3fv(glGetUniformLocation(prog, "u_lvec"), 1,
		 backLightVector);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, NULL);
    glFinish();
    /*
     * Reversing the element order while retaining +Z normals makes this a
     * back face.  The Obol shader must flip that normal to -Z, toward the
     * corresponding -Z light.
     */
    {
	static const GLuint reverseVboIndices[] = {0, 2, 1};
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(reverseVboIndices),
		     reverseVboIndices, GL_STATIC_DRAW);
	glClear(GL_COLOR_BUFFER_BIT);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, NULL);
	glFinish();
	glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE,
		     backLitPx);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(vboIndices), vboIndices,
		     GL_STATIC_DRAW);
    }

    glUniformMatrix4fv(glGetUniformLocation(prog, "u_model"), 1, GL_FALSE,
		       rotateY90);
    glUniformMatrix4fv(glGetUniformLocation(prog, "u_viewProj"), 1, GL_FALSE,
		       rotateYMinus90);
    glUniform3fv(glGetUniformLocation(prog, "u_lvec"), 1,
		 rotatedLightVector);
    glBindBuffer(GL_ARRAY_BUFFER, normalBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(rotationNormals), rotationNormals,
		 GL_STATIC_DRAW);
    glClear(GL_COLOR_BUFFER_BIT);
    glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, NULL);
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, rotatedPx);
    glDisableVertexAttribArray((GLuint) posLoc);
    glDisableVertexAttribArray((GLuint) normLoc);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glDeleteBuffers(1, &positionBuffer);
    glDeleteBuffers(1, &normalBuffer);
    glDeleteBuffers(1, &indexBuffer);
    glUseProgram(0);
    glDeleteProgram(prog);

    if (check_gl_error("glsl_obol_cad_shading")) {
	fprintf(stderr, "  FAIL: GL error during Obol shaded test\n");
	g_failed++;
    } else if (px[0] > 240 && px[1] > 240 && px[2] > 240) {
	printf("  PASS: Obol shaded contract produced white (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: Obol shaded contract produced (%d,%d,%d), "
		"expected white\n", px[0], px[1], px[2]);
	g_failed++;
    }
    if (rotatedPx[0] > 240 && rotatedPx[1] > 240 &&
	rotatedPx[2] > 240) {
	printf("  PASS: transformed Obol normal produced white (%d,%d,%d)\n",
	       rotatedPx[0], rotatedPx[1], rotatedPx[2]);
    } else {
	fprintf(stderr,
		"  FAIL: transformed Obol normal produced (%d,%d,%d), "
		"expected white\n",
		rotatedPx[0], rotatedPx[1], rotatedPx[2]);
	g_failed++;
    }
    if (backLitPx[0] > 240 && backLitPx[1] > 240 &&
	backLitPx[2] > 240) {
	printf("  PASS: Obol back-face normal flip produced white (%d,%d,%d)\n",
	       backLitPx[0], backLitPx[1], backLitPx[2]);
    } else {
	fprintf(stderr,
		"  FAIL: Obol back-face normal flip produced (%d,%d,%d), "
		"expected white\n",
		backLitPx[0], backLitPx[1], backLitPx[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18f: branchless Obol PoP specialization                        */
/* ------------------------------------------------------------------ */
static void
test_glsl_obol_pop_specialized(int W, int H)
{
    const char *vert =
	"#version 110\n"
	"uniform vec3 u_testPosition;\n"
	"uniform vec3 u_popEncodeScale;\n"
	"uniform vec3 u_popDecodeScale;\n"
	"uniform vec3 u_popMin;\n"
	"varying vec3 v_snapped;\n"
	"void main() {\n"
	"  vec3 scaled = (u_testPosition - u_popMin) * u_popEncodeScale;\n"
	"  vec3 low = floor(scaled);\n"
	"  vec3 high = ceil(scaled);\n"
	"  v_snapped = (low + high) * u_popDecodeScale + u_popMin;\n"
	"  gl_Position = gl_Vertex;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"uniform vec3 u_popMin;\n"
	"uniform vec3 u_popExtent;\n"
	"varying vec3 v_snapped;\n"
	"void main() {\n"
	"  gl_FragColor = vec4((v_snapped - u_popMin) / u_popExtent, 1.0);\n"
	"}\n";
    const GLfloat minimum[3] = {-2.0f, -2.0f, -2.0f};
    const GLfloat maximum[3] = {2.0f, 2.0f, 2.0f};
    const GLfloat position[3] = {0.123f, -0.777f, 1.333f};
    const GLfloat mask = 64.0f;
    GLfloat encode[3], decode[3], extent[3];
    GLubyte expected[3], px[4] = {0};
    GLuint program;
    int axis;

    printf("Test 18f: branchless Obol PoP specialization\n");
    for (axis = 0; axis < 3; ++axis) {
	const GLfloat scaled =
	    (position[axis] - minimum[axis]) /
	    (maximum[axis] - minimum[axis]) * 65535.0f;
	const GLfloat low = floorf(floorf(scaled) / mask);
	const GLfloat high = ceilf(ceilf(scaled) / mask);
	const GLfloat snapped = (low + high) * 0.5f * mask;
	GLfloat normalized = snapped / 65535.0f;
	extent[axis] = maximum[axis] - minimum[axis];
	encode[axis] = 65535.0f / (extent[axis] * mask);
	decode[axis] = 0.5f * mask * extent[axis] / 65535.0f;
	if (normalized < 0.0f)
	    normalized = 0.0f;
	else if (normalized > 1.0f)
	    normalized = 1.0f;
	expected[axis] = (GLubyte) (normalized * 255.0f + 0.5f);
    }

    program = make_program(vert, frag);
    if (!program) {
	fprintf(stderr, "  FAIL: specialized Obol PoP program failed\n");
	g_failed++;
	return;
    }
    glUseProgram(program);
    glUniform3fv(glGetUniformLocation(program, "u_testPosition"), 1,
		 position);
    glUniform3fv(glGetUniformLocation(program, "u_popEncodeScale"), 1,
		 encode);
    glUniform3fv(glGetUniformLocation(program, "u_popDecodeScale"), 1,
		 decode);
    glUniform3fv(glGetUniformLocation(program, "u_popMin"), 1, minimum);
    glUniform3fv(glGetUniformLocation(program, "u_popExtent"), 1, extent);
    glViewport(0, 0, W, H);
    glDisable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f( 1.0f, -1.0f);
    glVertex2f( 1.0f,  1.0f);
    glVertex2f(-1.0f,  1.0f);
    glEnd();
    glFinish();
    glReadPixels(W / 2, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glUseProgram(0);
    glDeleteProgram(program);

    if (check_gl_error("glsl_obol_pop_specialized")) {
	fprintf(stderr, "  FAIL: GL error during specialized Obol PoP test\n");
	g_failed++;
    } else if (abs((int)px[0] - (int)expected[0]) <= 2 &&
	       abs((int)px[1] - (int)expected[1]) <= 2 &&
	       abs((int)px[2] - (int)expected[2]) <= 2) {
	printf("  PASS: branchless PoP snap produced (%d,%d,%d)\n",
	       px[0], px[1], px[2]);
    } else {
	fprintf(stderr,
		"  FAIL: branchless PoP snap produced (%d,%d,%d), "
		"expected (%d,%d,%d)\n",
		px[0], px[1], px[2],
		expected[0], expected[1], expected[2]);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 18g: batched GLSL vertex execution plus scalar tail            */
/* ------------------------------------------------------------------ */
static void
test_glsl_vertex_batch_tail(int W, int H)
{
    const char *vert =
	"#version 110\n"
	"void main() {\n"
	"  vec4 quarter = gl_Vertex * vec4(0.25);\n"
	"  gl_Position = quarter + gl_Vertex * vec4(0.75);\n"
	"  gl_FrontColor = gl_Color;\n"
	"}\n";
    const char *frag =
	"#version 110\n"
	"void main() { gl_FragColor = gl_Color; }\n";
    GLfloat positions[5][4];
    static const GLfloat colors[5][4] = {
	{1.0f, 0.0f, 0.0f, 1.0f},
	{0.0f, 1.0f, 0.0f, 1.0f},
	{0.0f, 0.0f, 1.0f, 1.0f},
	{1.0f, 1.0f, 0.0f, 1.0f},
	{1.0f, 0.0f, 1.0f, 1.0f}
    };
    GLubyte expected[5][3] = {
	{255, 0, 0}, {0, 255, 0}, {0, 0, 255},
	{255, 255, 0}, {255, 0, 255}
    };
    GLuint program;
    int i;
    int ok = 1;

    printf("Test 18g: batched GLSL vertex execution with scalar tail\n");
    program = make_program(vert, frag);
    if (!program) {
	fprintf(stderr, "  FAIL: batch-tail GLSL program failed\n");
	g_failed++;
	return;
    }

    for (i = 0; i < 5; ++i) {
	const int x = (i + 1) * W / 6;
	positions[i][0] = (2.0f * ((GLfloat)x + 0.5f) / W) - 1.0f;
	positions[i][1] =
	    (2.0f * ((GLfloat)(H / 2) + 0.5f) / H) - 1.0f;
	positions[i][2] = 0.0f;
	positions[i][3] = 1.0f;
    }

    glViewport(0, 0, W, H);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glDisable(GL_DITHER);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(program);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);
    glVertexPointer(4, GL_FLOAT, 0, positions);
    glColorPointer(4, GL_FLOAT, 0, colors);
    glDrawArrays(GL_POINTS, 0, 5);
    glFinish();

    for (i = 0; i < 5; ++i) {
	const int x = (i + 1) * W / 6;
	GLubyte px[4] = {0};
	glReadPixels(x, H / 2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, px);
	if (abs((int)px[0] - (int)expected[i][0]) > 1 ||
	    abs((int)px[1] - (int)expected[i][1]) > 1 ||
	    abs((int)px[2] - (int)expected[i][2]) > 1) {
	    fprintf(stderr,
		    "  FAIL: batch-tail vertex %d produced (%d,%d,%d), "
		    "expected (%d,%d,%d)\n",
		    i, px[0], px[1], px[2],
		    expected[i][0], expected[i][1], expected[i][2]);
	    ok = 0;
	}
    }

    glDisableClientState(GL_COLOR_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glUseProgram(0);
    glDeleteProgram(program);
    if (check_gl_error("glsl_vertex_batch_tail"))
	ok = 0;
    if (ok)
	printf("  PASS: four batched vertices and one scalar tail matched\n");
    else
	g_failed++;
}

/* ------------------------------------------------------------------ */
/* Test 19: GL_ARB_occlusion_query                                     */
/* ------------------------------------------------------------------ */
static void
test_occlusion_query(int W, int H)
{
    printf("Test 19: GL_ARB_occlusion_query\n");

    if (!check_ext("GL_ARB_occlusion_query"))
	return;

    clear_errors();

    GLuint queries[2];
    glGenQueriesARB(2, queries);

    glViewport(0, 0, W, H);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /*
     * With identity matrices, vertex z values are NDC z directly.
     * z_ndc → z_window = (z_ndc + 1) / 2:
     *   z_ndc =  0.0 → depth = 0.5
     *   z_ndc =  0.5 → depth = 0.75   (farther; fails GL_LEQUAL after 0.5 written)
     *
     * Query 0: render a visible full-screen quad at z_ndc=0 → should pass many samples
     */
    glBeginQueryARB(GL_SAMPLES_PASSED_ARB, queries[0]);
    glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-1.0f, -1.0f,  0.0f);
    glVertex3f( 1.0f, -1.0f,  0.0f);
    glVertex3f( 1.0f,  1.0f,  0.0f);
    glVertex3f(-1.0f,  1.0f,  0.0f);
    glEnd();
    glEndQueryARB(GL_SAMPLES_PASSED_ARB);

    /*
     * Query 1: render a full-screen quad at z_ndc=0.5 (depth=0.75).
     * Stored depth is 0.5 (from previous quad).
     * GL_LEQUAL: 0.75 <= 0.5 is FALSE → all fragments rejected → 0 samples.
     */
    glBeginQueryARB(GL_SAMPLES_PASSED_ARB, queries[1]);
    glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-1.0f, -1.0f,  0.5f);
    glVertex3f( 1.0f, -1.0f,  0.5f);
    glVertex3f( 1.0f,  1.0f,  0.5f);
    glVertex3f(-1.0f,  1.0f,  0.5f);
    glEnd();
    glEndQueryARB(GL_SAMPLES_PASSED_ARB);

    glFinish();
    glDisable(GL_DEPTH_TEST);

    GLuint result0 = 0, result1 = 0;
    glGetQueryObjectuivARB(queries[0], GL_QUERY_RESULT_ARB, &result0);
    glGetQueryObjectuivARB(queries[1], GL_QUERY_RESULT_ARB, &result1);

    glDeleteQueriesARB(2, queries);

    if (check_gl_error("occlusion_query")) {
	fprintf(stderr, "  FAIL: GL error during occlusion query test\n");
	g_failed++;
	return;
    }

    if (result0 > 0 && result1 == 0) {
	printf("  PASS: occlusion query visible=%u occluded=%u\n",
	       result0, result1);
    } else {
	fprintf(stderr,
		"  FAIL: occlusion query visible=%u (expected >0) "
		"occluded=%u (expected 0)\n",
		result0, result1);
	g_failed++;
    }
}

/* ------------------------------------------------------------------ */
/* Test 20: GL_ARB_framebuffer_sRGB                                    */
/* ------------------------------------------------------------------ */
static void
test_framebuffer_srgb(int W, int H)
{
    printf("Test 20: GL_ARB_framebuffer_sRGB\n");

    if (!check_ext("GL_ARB_framebuffer_sRGB") &&
	!check_ext("GL_EXT_framebuffer_sRGB")) {
	return;
    }

    /* Test 1: GL_FRAMEBUFFER_SRGB_CAPABLE_EXT should be TRUE */
    {
	GLboolean capable = GL_FALSE;
	glGetBooleanv(GL_FRAMEBUFFER_SRGB_CAPABLE_EXT, &capable);
	if (check_gl_error("sRGB capable query"))
	    g_failed++;
	else if (!capable) {
	    fprintf(stderr, "  FAIL: GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = FALSE\n");
	    g_failed++;
	} else
	    printf("  PASS: GL_FRAMEBUFFER_SRGB_CAPABLE_EXT = TRUE\n");
    }

    /* Test 2: glEnable/glDisable GL_FRAMEBUFFER_SRGB_EXT should not error */
    {
	glEnable(GL_FRAMEBUFFER_SRGB_EXT);
	if (check_gl_error("glEnable(GL_FRAMEBUFFER_SRGB_EXT)")) {
	    g_failed++;
	} else {
	    GLboolean en = glIsEnabled(GL_FRAMEBUFFER_SRGB_EXT);
	    if (!en) {
		fprintf(stderr, "  FAIL: glIsEnabled(GL_FRAMEBUFFER_SRGB_EXT) = FALSE after enable\n");
		g_failed++;
	    } else
		printf("  PASS: glEnable/glIsEnabled GL_FRAMEBUFFER_SRGB_EXT\n");
	}
	glDisable(GL_FRAMEBUFFER_SRGB_EXT);
    }

    /* Test 3: sRGB FBO: create sRGB renderbuffer, check color encoding */
    {
	GLuint fbo, rbo;
	GLenum status;
	GLint encoding = 0;

	glGenFramebuffersEXT(1, &fbo);
	glGenRenderbuffersEXT(1, &rbo);
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fbo);
	glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, rbo);
	glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_SRGB8_ALPHA8_EXT, W, H);
	if (check_gl_error("glRenderbufferStorageEXT(GL_SRGB8_ALPHA8_EXT)")) {
	    fprintf(stderr, "  FAIL: could not create SRGB8_ALPHA8 renderbuffer\n");
	    g_failed++;
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	    glDeleteRenderbuffersEXT(1, &rbo);
	    glDeleteFramebuffersEXT(1, &fbo);
	    return;
	}
	glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT,
				     GL_COLOR_ATTACHMENT0_EXT,
				     GL_RENDERBUFFER_EXT, rbo);
	status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
	if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
	    fprintf(stderr, "  FAIL: sRGB FBO incomplete (status=0x%x)\n", status);
	    g_failed++;
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	    glDeleteRenderbuffersEXT(1, &rbo);
	    glDeleteFramebuffersEXT(1, &fbo);
	    return;
	}

	/* Query color encoding - should return GL_SRGB */
	glGetFramebufferAttachmentParameterivEXT(GL_FRAMEBUFFER_EXT,
						 GL_COLOR_ATTACHMENT0_EXT,
						 GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING,
						 &encoding);
	if (check_gl_error("GetFramebufferAttachmentParameteriv COLOR_ENCODING"))
	    g_failed++;
	else if (encoding != GL_SRGB) {
	    fprintf(stderr, "  FAIL: COLOR_ENCODING=0x%x (expected GL_SRGB=0x8C40)\n",
		    encoding);
	    g_failed++;
	} else
	    printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = GL_SRGB\n");

	/* Test 4: render a linear 50% gray (128,128,128) with sRGB encoding on
	 * and verify it reads back as approximately the sRGB-encoded value.
	 * Linear 128/255 ≈ 0.502  →  sRGB ≈ 0.730 ≈ 186 */
	{
	    GLubyte pixel[4];
	    GLint expected = 186;
	    GLint tolerance = 4;

	    glViewport(0, 0, W, H);
	    glEnable(GL_FRAMEBUFFER_SRGB_EXT);
	    glDisable(GL_DITHER);
	    glClearColor(128.0f / 255.0f, 128.0f / 255.0f, 128.0f / 255.0f, 1.0f);
	    glClear(GL_COLOR_BUFFER_BIT);

	    /* Read back - the clear goes through the normal path, but a drawn
	     * quad definitely goes through the sRGB encode path */
	    glColor3f(128.0f / 255.0f, 128.0f / 255.0f, 128.0f / 255.0f);
	    glBegin(GL_QUADS);
	    glVertex2f(-1, -1); glVertex2f(1, -1);
	    glVertex2f(1,  1);  glVertex2f(-1,  1);
	    glEnd();
	    glDisable(GL_FRAMEBUFFER_SRGB_EXT);

	    glReadPixels(W/2, H/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, pixel);
	    if (abs((int)pixel[0] - expected) <= tolerance)
		printf("  PASS: sRGB encode: linear %d -> sRGB %d (expected ~%d)\n",
		       128, pixel[0], expected);
	    else {
		fprintf(stderr,
			"  FAIL: sRGB encode: linear 128 -> %d (expected ~%d)\n",
			pixel[0], expected);
		g_failed++;
	    }
	}

	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	glDeleteRenderbuffersEXT(1, &rbo);
	glDeleteFramebuffersEXT(1, &fbo);
    }
}


/* ------------------------------------------------------------------ */
/* Test 21: GL_EXT_texture_integer                                     */
/* ------------------------------------------------------------------ */
static void
test_texture_integer(int W, int H)
{
    printf("Test 21: GL_EXT_texture_integer\n");

    if (!check_ext("GL_EXT_texture_integer"))
	return;

    /* Test 1: glClearColorIiEXT / glClearColorIuiEXT should not error */
    {
	glClearColorIiEXT(255, 128, 0, 255);
	if (check_gl_error("glClearColorIiEXT")) {
	    g_failed++;
	} else
	    printf("  PASS: glClearColorIiEXT no error\n");

	glClearColorIuiEXT(255, 128, 0, 255);
	if (check_gl_error("glClearColorIuiEXT")) {
	    g_failed++;
	} else
	    printf("  PASS: glClearColorIuiEXT no error\n");
    }

    /* Test 2: Create integer RBO, check COMPONENT_TYPE */
    {
	GLuint fbo, rbo;
	GLenum status;
	GLint comp_type = 0;

	glGenFramebuffersEXT(1, &fbo);
	glGenRenderbuffersEXT(1, &rbo);
	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fbo);
	glBindRenderbufferEXT(GL_RENDERBUFFER_EXT, rbo);
	glRenderbufferStorageEXT(GL_RENDERBUFFER_EXT, GL_RGBA8UI_EXT, W, H);
	if (check_gl_error("glRenderbufferStorageEXT(GL_RGBA8UI_EXT)")) {
	    fprintf(stderr, "  FAIL: could not create RGBA8UI renderbuffer\n");
	    g_failed++;
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	    glDeleteRenderbuffersEXT(1, &rbo);
	    glDeleteFramebuffersEXT(1, &fbo);
	    return;
	}
	glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT,
				     GL_COLOR_ATTACHMENT0_EXT,
				     GL_RENDERBUFFER_EXT, rbo);
	status = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
	if (status != GL_FRAMEBUFFER_COMPLETE_EXT) {
	    fprintf(stderr, "  FAIL: integer FBO incomplete (status=0x%x)\n", status);
	    g_failed++;
	    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	    glDeleteRenderbuffersEXT(1, &rbo);
	    glDeleteFramebuffersEXT(1, &fbo);
	    return;
	}
	printf("  PASS: GL_RGBA8UI renderbuffer created and FBO complete\n");

	/* Check COMPONENT_TYPE = GL_UNSIGNED_INT */
	glGetFramebufferAttachmentParameterivEXT(GL_FRAMEBUFFER_EXT,
						 GL_COLOR_ATTACHMENT0_EXT,
						 GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE,
						 &comp_type);
	if (check_gl_error("GetFramebufferAttachmentParameteriv COMPONENT_TYPE"))
	    g_failed++;
	else if (comp_type != GL_UNSIGNED_INT) {
	    fprintf(stderr, "  FAIL: COMPONENT_TYPE=0x%x (expected GL_UNSIGNED_INT=0x%x)\n",
		    comp_type, GL_UNSIGNED_INT);
	    g_failed++;
	} else
	    printf("  PASS: GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = GL_UNSIGNED_INT\n");

	/* Test GL_RGBA_INTEGER_MODE_EXT query */
	{
	    GLint int_mode = 0;
	    glGetIntegerv(GL_RGBA_INTEGER_MODE_EXT, &int_mode);
	    if (check_gl_error("GL_RGBA_INTEGER_MODE_EXT query"))
		g_failed++;
	    else if (!int_mode) {
		fprintf(stderr, "  FAIL: GL_RGBA_INTEGER_MODE_EXT = 0 (expected 1)\n");
		g_failed++;
	    } else
		printf("  PASS: GL_RGBA_INTEGER_MODE_EXT = 1 with integer draw buffer\n");
	}

	glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
	glDeleteRenderbuffersEXT(1, &rbo);
	glDeleteFramebuffersEXT(1, &fbo);
    }

    /* Test 3: Check that extension is advertised */
    {
	const char *exts = (const char *)glGetString(GL_EXTENSIONS);
	if (exts && strstr(exts, "GL_EXT_texture_integer"))
	    printf("  PASS: GL_EXT_texture_integer in extension string\n");
	else {
	    fprintf(stderr, "  FAIL: GL_EXT_texture_integer not in extension string\n");
	    g_failed++;
	}
    }
}


/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */

int
main(void)
{
    int W = 64, H = 64;

    /* 16-bit depth: sufficient precision for all depth/shadow/occlusion tests */
    OSMesaContext ctx = OSMesaCreateContextExt(OSMESA_RGBA, 16, 0, 0, NULL);
    if (!ctx) {
	fprintf(stderr, "OSMesaCreateContext failed\n");
	return 1;
    }

    GLubyte *fb = (GLubyte *)calloc(W * H * 4, sizeof(GLubyte));
    if (!fb) {
	fprintf(stderr, "Out of memory\n");
	OSMesaDestroyContext(ctx);
	return 1;
    }

    if (!OSMesaMakeCurrent(ctx, fb, GL_UNSIGNED_BYTE, W, H)) {
	fprintf(stderr, "OSMesaMakeCurrent failed\n");
	free(fb);
	OSMesaDestroyContext(ctx);
	return 1;
    }
    OSMesaPixelStore(OSMESA_Y_UP, 0);

    printf("OpenGL renderer: %s\n", glGetString(GL_RENDERER));
    printf("OpenGL version:  %s\n", glGetString(GL_VERSION));
    printf("\n");

    test_extension_strings();
    test_polygon_offset(W, H);
    test_texture_object(W, H);
    test_subtexture(W, H);
    test_texture3d(W, H);
    test_multitexture(W, H);
    test_texture_compression();
    test_paletted_texture(W, H);
    test_blend_minmax(W, H);
    test_sgi_color_table(W, H);
    test_vbo(W, H);
    test_multi_draw_arrays(W, H);
    test_depth_texture(W, H);
    test_fbo_depth_texture(W, H);
    test_arb_fbo(W, H);
    test_shadow(W, H);
    test_texture_rectangle(W, H);
    test_vertex_program(W, H);
    test_fragment_program(W, H);
    test_glsl_shader(W, H);
    test_glsl_uniform_array_index(W, H);
    test_glsl_uniform_matrix_vector(W, H);
    test_glsl_shared_uniform_stages(W, H);
    test_glsl_uniform_struct(W, H);
    test_glsl_uniform_struct_texture(W, H);
    test_glsl_drawelements(W, H);
    test_glsl_line_varying(W, H);
    test_glsl_perspective_derivatives(W, H);
    test_glsl_obol_cad_shading(W, H);
    test_glsl_obol_pop_specialized(W, H);
    test_glsl_vertex_batch_tail(W, H);
    test_occlusion_query(W, H);
    test_framebuffer_srgb(W, H);
    test_texture_integer(W, H);

    printf("\n");
    if (g_failed == 0) {
	printf("All tests PASSED\n");
    } else {
	printf("%d test(s) FAILED\n", g_failed);
    }

    free(fb);
    OSMesaDestroyContext(ctx);

    return g_failed ? 1 : 0;
}

/*
 * Local Variables:
 * tab-width: 8
 * mode: C
 * indent-tabs-mode: t
 * c-file-style: "stroustrup"
 * End:
 * ex: shiftwidth=4 tabstop=8 cino=N-s
 */
