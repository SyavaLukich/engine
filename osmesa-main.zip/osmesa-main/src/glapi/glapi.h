/*
 * Mesa 3-D graphics library
 * Version:  6.5
 *
 * Copyright (C) 1999-2006  Brian Paul   All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * BRIAN PAUL BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


/**
 * \mainpage Mesa GL API Module
 *
 * \section GLAPIIntroduction Introduction
 *
 * The Mesa GL API module is responsible for dispatching all the
 * gl*() functions.  All GL functions are dispatched by jumping through
 * the current dispatch table (basically a struct full of function
 * pointers.)
 *
 * A per-thread current dispatch table and per-thread current context
 * pointer are managed by this module too.
 *
 * This module is intended to be non-Mesa-specific so it can be used
 * with the X/DRI libGL also.
 */


#ifndef _GLAPI_H
#define _GLAPI_H


#include "OSMesa/gl.h"
#include "glapitable.h"

typedef void (*_glapi_warning_func)(void *ctx, const char *str, ...);

/*
 * glapi.h is commonly included before glthread.h (context.h is one such
 * path).  Establish the same THREADS feature test here so
 * GET_CURRENT_CONTEXT() never gets compiled in single-thread-only form for
 * a threaded build.  Once _glapi_check_multithread() moves the current
 * context into TSD, consulting only _glapi_Context yields NULL and causes
 * core entry points to dereference a nonexistent context.
 */
#if (defined(PTHREADS) || defined(SOLARIS_THREADS) || \
     defined(WIN32_THREADS) || defined(USE_XTHREADS)) && !defined(THREADS)
# define THREADS
#endif


#if defined(USE_MGL_NAMESPACE)
#define _glapi_set_dispatch _mglapi_set_dispatch
#define _glapi_get_dispatch _mglapi_get_dispatch
#define _glapi_set_context _mglapi_set_context
#define _glapi_get_context _mglapi_get_context
#define _glapi_Context _mglapi_Context
#define _glapi_Dispatch _mglapi_Dispatch
#define _glapi_noop_enable_warnings _mglapi_noop_enable_warnings
#define _glapi_set_warning_func _mglapi_set_warning_func
#define _glapi_check_multithread _mglapi_check_multithread
#define _glapi_begin_dispatch_override _mglapi_begin_dispatch_override
#define _glapi_end_dispatch_override _mglapi_end_dispatch_override
#define _glapi_get_override_dispatch _mglapi_get_override_dispatch
#define _glapi_add_dispatch _mglapi_add_dispatch
#define _glapi_get_proc_offset _mglapi_get_proc_offset
#define _glapi_get_proc_address _mglapi_get_proc_address
#define _glapi_get_proc_name _mglapi_get_proc_name
#endif


/**
 ** Define the GET_CURRENT_CONTEXT() macro.
 ** \param C local variable which will hold the current context.
 **/

extern void *_glapi_Context;
extern struct _glapi_table *_glapi_Dispatch;

# ifdef THREADS
#  define GET_CURRENT_CONTEXT(C)  GLcontext *C = (GLcontext *) (_glapi_Context ? _glapi_Context : _glapi_get_context())
# else
#  define GET_CURRENT_CONTEXT(C)  GLcontext *C = (GLcontext *) _glapi_Context
# endif



/**
 ** GL API public functions
 **/

extern void
_glapi_noop_enable_warnings(GLboolean enable);

extern void
_glapi_set_warning_func(_glapi_warning_func func);

extern void
_glapi_check_multithread(void);


extern void
_glapi_set_context(void *context);


extern void *
_glapi_get_context(void);


extern void
_glapi_set_dispatch(struct _glapi_table *dispatch);


extern struct _glapi_table *
_glapi_get_dispatch(void);

extern int
_glapi_begin_dispatch_override(struct _glapi_table *override);


extern void
_glapi_end_dispatch_override(int layer);


struct _glapi_table *
_glapi_get_override_dispatch(int layer);


extern int
_glapi_add_dispatch(const char * const * function_names,
		    const char * parameter_signature);

extern GLint
_glapi_get_proc_offset(const char *funcName);


extern _glapi_proc
_glapi_get_proc_address(const char *funcName);


extern const char *
_glapi_get_proc_name(GLuint offset);

#endif

/*
 * Local Variables:
 * tab-width: 8
 * mode: C
 * indent-tabs-mode: t
 * c-file-style: "stroustrup"
 * End:
 * ex: shiftwidth=4 tabstop=8
 */
